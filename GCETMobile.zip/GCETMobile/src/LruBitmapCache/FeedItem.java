package LruBitmapCache;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class FeedItem {
    private int id;
    private String name, status, roll_no, profilePic, timeStamp,branch;
 
    public FeedItem() {
    }
 
    public FeedItem(int id, String name, String roll_no, String status,
            String profilePic, String timeStamp, String branch) {
        super();
        this.id = id;
        this.name = name;
        this.roll_no = roll_no;
        this.status = status;
        this.profilePic = profilePic;
        this.timeStamp = timeStamp;
        this.branch=branch;
    }
 
    public int getId() {
        return id;
    }
 
    public void setId(int id) {
        this.id = id;
    }
 
    public String getName() {
        return name;
    }
 
    public void setName(String name) {
        this.name = name;
    }
 
//    public String getImge() {
//        return image;
//    }
// 
//    public void setImge(String image) {
//        this.image = image;
//    }
    
    public String getRoll_no() {
      return roll_no;
  }

  public void setRoll_no(String roll_no) {
      this.roll_no = roll_no;
  }
 
    public String getStatus() {
        return status;
    }
 
    public void setStatus(String status) {
        this.status = status;
    }
 
    public String getProfilePic() {
        return profilePic;
    }
 
    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }
 
    public String getTimeStamp() {
        return timeStamp;
    }
 
    public void setTimeStamp(String timeStamp) {
    	 SimpleDateFormat displayFormat = new SimpleDateFormat ("MMM dd,yyyy | hh:mm a ",Locale.US);
		 SimpleDateFormat parseFormat = new SimpleDateFormat ("yyyy-MM-dd H:mm:ss",Locale.US);
		 Date t=new Date();
		try {
			t = parseFormat.parse(timeStamp);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
        this.timeStamp = displayFormat.format(t);
    }
 
    public String getBranch() {
        return branch;
    }
 
    public void setBranch(String branch) {
        this.branch = branch;
    }
}