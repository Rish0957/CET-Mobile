package LruBitmapCache;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class NotificationItem {
    private int id;
    private String name, designation, content, timestamp,branch;
 
    public NotificationItem() {
    }
 
    public NotificationItem(int id, String name, String content, String designation,String timestamp, String branch) {
        super();
        this.id = id;
        this.name = name;
        this.content = content;
        this.designation = designation;
        this.timestamp = timestamp;
        this.branch=branch;
    }
 
    public int getId() {
        return id;
    }
 
    public void setId(int id) {
        this.id = id;
    }
 
    public String getName() {
        return name;
    }
 
    public void setName(String name) {
        this.name = name;
    }
 
    
    public String getContent() {
      return content;
  }

  public void setContent(String content) {
      this.content = content;
  }
 
    public String getDesignation() {
        return designation;
    }
 
    public void setDesignation(String designation) {
        this.designation = designation;
    }
 
    public String getTimeStamp() {
        return timestamp;
    }
 
    public void setTimeStamp(String timestamp) {
    	 SimpleDateFormat displayFormat = new SimpleDateFormat ("MMM dd,yyyy | hh:mm a ",Locale.US);
		 SimpleDateFormat parseFormat = new SimpleDateFormat ("yyyy-MM-dd H:mm:ss",Locale.US);
		 Date t=new Date();
		try {
			t = parseFormat.parse(timestamp);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
        this.timestamp = displayFormat.format(t);
    }
 
    public String getBranch() {
        return branch;
    }
 
    public void setBranch(String branch) {
        this.branch = branch;
    }
}