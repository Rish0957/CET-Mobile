package LruBitmapCache;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ClassmateItem {
    private int id;
    private String name,roll_no,timeStamp;
 
    public ClassmateItem() {
    }
 
    public ClassmateItem(int id, String name, String roll_no, String timeStamp) {
        super();
        this.id = id;
        this.name = name;
        this.roll_no = roll_no;
        this.timeStamp = timeStamp;
    }
 
    public int getId() {
        return id;
    }
 
    public void setId(int id) {
        this.id = id;
    }
 
    public String getName() {
        return name;
    }
 
    public void setName(String name) {
        this.name = name;
    }
 
    public String getRoll_no() {
      return roll_no;
  }

  public void setRoll_no(String roll_no) {
      this.roll_no = roll_no;
  }
 
 
    public String getTimeStamp() {
        return timeStamp;
    }
 
    public void setTimeStamp(String timeStamp) {
    	 SimpleDateFormat displayFormat = new SimpleDateFormat ("MMM dd,yyyy",Locale.US);
		 SimpleDateFormat parseFormat = new SimpleDateFormat ("yyyy-MM-dd H:mm:ss",Locale.US);
		 Date t=new Date();
			try {
				t = parseFormat.parse(timeStamp);
			} catch (java.text.ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    
        this.timeStamp = displayFormat.format(t);
    }
 
}