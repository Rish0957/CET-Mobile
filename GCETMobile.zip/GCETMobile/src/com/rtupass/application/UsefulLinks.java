package com.rtupass.application;

import java.util.ArrayList;

import com.rtupass.application.helper.SessionManager;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class UsefulLinks extends Fragment {
	ListView list;
	SQLiteDatabase database;
	public ArrayList<String> name,url;
	private String DB_NAME="college.db";
	String company_name;
	ArrayAdapter<String> listAdapter;
	@Override
	    public View onCreateView(LayoutInflater inflater, ViewGroup container,
	            Bundle savedInstanceState) {
	 
	        View notes = inflater.inflate(R.layout.placement_links, container, false);
	        list=(ListView)notes.findViewById(R.id.listView1);
	        company_name=new SessionManager(getActivity()).getCompany();
	        database=getActivity().openOrCreateDatabase(DB_NAME, Context.MODE_PRIVATE,null);
	        try {
				name=new ArrayList<String>();
				url=new ArrayList<String>();
			String query= "select u.content,u.url from useful_links u INNER JOIN company c ON u.company_id=c.id ";
			query+="where company_name='"+company_name+"' order by u.id asc";
				Cursor c=database.rawQuery(query, null);
				c.moveToFirst();
				if(!c.isAfterLast()) {
					do {
						String linkName = c.getString(0);
						String linkUrl=c.getString(1);
						name.add(linkName);
						url.add(linkUrl);
					} while (c.moveToNext());
				}
				c.close();
				listAdapter=new ArrayAdapter<>(getActivity(),android.R.layout.simple_list_item_1, name);
				list.setAdapter(listAdapter);
				list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
						// TODO Auto-generated method stub						
						Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url.get(arg2)));
						startActivity(browserIntent);
			
					}
				});
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	       database.close();
	        
	        return notes;
}
	
}
