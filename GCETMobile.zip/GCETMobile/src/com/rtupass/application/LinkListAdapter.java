package com.rtupass.application;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class LinkListAdapter extends BaseAdapter{
	ArrayList<String> titles=new ArrayList<String>();
	ArrayList<String> urls=new ArrayList<String>();
	 Context con;
	 LayoutInflater inflater;

	public LinkListAdapter(Context context,ArrayList<String> title,ArrayList<String> url) {
		titles=title;
		urls=url;
		con =context;
		// TODO Auto-generated constructor stub
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return titles.size();
	}

	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return titles.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return arg0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
 
        if (inflater == null)
            inflater = (LayoutInflater) con.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null)
            convertView = inflater.inflate(R.layout.link_item, null);
 
        TextView link_title = (TextView) convertView.findViewById(R.id.title);
        TextView link_url = (TextView) convertView.findViewById(R.id.url);
        
        link_title.setText(titles.get(position));
        link_url.setText(urls.get(position));
        
        return convertView;
    }

}