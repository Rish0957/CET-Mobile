package com.rtupass.application;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import android.app.ActionBar;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

public class GCETMap extends Activity {
	   ActionBar ab;	 
	   private GoogleMap googleMap;
	 //  private ConnectionDetector cd;
	  // private Boolean isInternetPresent;
	   static Double latitude=28.066115,longitude=73.289073;
	   // Alert Dialog Manager
		//AlertDialogManager alert = new AlertDialogManager();
		static final LatLng GCET_Location = new LatLng(latitude ,longitude);
	   @Override
	   protected void onCreate(Bundle savedInstanceState) {
	      super.onCreate(savedInstanceState);
	      setContentView(R.layout.activity_gcetmap);
	 // 	cd = new ConnectionDetector(getApplicationContext());
	      ab=getActionBar();
		// Check if Internet present
//		isInternetPresent = cd.isConnectingToInternet();
//		Toast.makeText(getApplicationContext(), "connected to internet: "+isInternetPresent,Toast.LENGTH_SHORT).show();
		
//		if (!isInternetPresent) {
//			// Internet Connection is not present
//			alert.showAlertDialog(GCETMap.this, "Internet Connection Error","Please connect to working Internet connection", false);
//			// stop executing code by return
//			return;
//		}
	      	ab.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#000000")));
	        ab.setIcon(new ColorDrawable(getResources().getColor(android.R.color.transparent)));
	        ab.setTitle("Map");	        
	        
	      try {
	         if (googleMap == null) {
	            googleMap = ((MapFragment) getFragmentManager().findFragmentById(R.id.map)).getMap();
	         }
	         googleMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
	         googleMap.moveCamera( CameraUpdateFactory.newLatLngZoom(new LatLng(latitude,longitude) , 16.0f) );
	         Marker TP = googleMap.addMarker(new MarkerOptions().position(GCET_Location).title("Govt. College of Engineering & Technology, Bikaner"));
	      }
	      catch (Exception e) {
	         e.printStackTrace();
	      }
	   }
}
