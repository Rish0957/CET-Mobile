package com.rtupass.application;

import java.util.ArrayList;

import com.rtupass.application.helper.SessionManager;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class PlacementCorner extends Activity{
	Spinner spinner_company;
	Button home,letsGo;
	private static final String DB_NAME = "college.db";
	private static final String TABLE_NAME_COMPANY = "company";
	String selected_company;
	private SQLiteDatabase database;
	private ArrayList<String> companies;
	ArrayAdapter<String>company_adapter;
	SessionManager session;
	ActionBar actionBar;
		
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_placement_corner);
	
		actionBar=getActionBar();
		actionBar.hide();
		ExternalDbOpenHelper dbOpenHelper = new ExternalDbOpenHelper(this, DB_NAME);
        database = dbOpenHelper.openDataBase();
        dbOpenHelper.close();
		spinner_company=(Spinner)findViewById(R.id.branch);
		letsGo=(Button)findViewById(R.id.btnLetsGo);
		home=(Button)findViewById(R.id.btnBackToHome);
		
		session = new SessionManager(getApplicationContext());
		
		
        database= openOrCreateDatabase(DB_NAME, Context.MODE_PRIVATE, null);
        createCompanyAdapter();
        database.close();
        
        spinner_company.setAdapter(company_adapter);
        
        
        spinner_company.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

		@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
				// TODO Auto-generated method stub
				selected_company=arg0.getItemAtPosition(arg2).toString();
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
        	
		});
        
        letsGo.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(!selected_company.equals(companies.get(0))){
		        	session.placementCorner(selected_company);
		        	Intent i=new Intent(PlacementCorner.this,CompanyTabActivity.class);
		        	startActivity(i);
		        }
				else{
					Toast.makeText(getApplicationContext(), "Select a company first!!", Toast.LENGTH_LONG).show();
				}
			}
		});
        home.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i=new Intent(PlacementCorner.this,MainActivity.class);
				startActivity(i);
				finish();
			}
		});
        
	}
	private void createCompanyAdapter(){
		companies=new ArrayList<String>();
		companies.add("----Select company----");
		String query= "SELECT company_name FROM "+TABLE_NAME_COMPANY;
		Cursor c=database.rawQuery(query, null);
		c.moveToFirst();
		if(!c.isAfterLast()) {
			do {
				String name = c.getString(0);
				companies.add(name);
			} while (c.moveToNext());
		}
		c.close();
		company_adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item, companies){
			 @Override
		     public View getDropDownView(int position, View convertView, ViewGroup parent) {
		         View view = super.getDropDownView(position, convertView, parent);
		        

		         // If this is the initial dummy entry, make it hidden
		         if (position == 0) {
		             TextView tv = new TextView(getContext());
		             tv.setHeight(0);
		             tv.setVisibility(View.GONE);
		             view = tv;
		         }
		         else {
		             // Pass convertView as null to prevent reuse of special case views
		             view = super.getDropDownView(position, null, parent);
		         }

		         // Hide scroll bar because it appears sometimes unnecessarily, this does not prevent scrolling 
		         parent.setVerticalScrollBarEnabled(false);
		         return view;
		     }
		 };
		}
	}
	

