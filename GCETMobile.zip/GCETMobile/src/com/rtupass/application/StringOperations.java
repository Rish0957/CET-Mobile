package com.rtupass.application;
import android.annotation.SuppressLint;
import android.util.Log;

import java.util.Calendar;

public class StringOperations {

	public String getYear(String roll_no){
		Calendar rightNow = Calendar.getInstance();
		String Year;
		if(isValidRollno(roll_no)){
			int student_year=Integer.parseInt(roll_no.substring(0, 2))+2000;
			int current_Year=rightNow.get(Calendar.YEAR);
			int int_year=(current_Year%student_year)+1;
			if(int_year>4){
				Year="Pass Out";
			}
			else{
				Year="You Entered Wrong Roll no.!!";
				if(int_year >0 && int_year<=4){
					Year=Integer.toString(int_year)+"th year";	
				}
				
			}
		}
		else{
			Year="You Entered Wrong Roll no.!!";
		}
		return Year;
	}

	public boolean isValidRollno(String roll_no){
		Boolean valid=false;
		try {
			String college_id=roll_no.substring(2, 5);
			int id=Integer.parseInt(roll_no.substring(7));
			Log.d(roll_no, id+"");
			if(roll_no.length()==10 && college_id.equalsIgnoreCase("ect") && id<140){
				valid=true;
			}
			return valid;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}
	
	
	@SuppressLint("DefaultLocale")
	public String getBranch(String roll_no){
		Log.d(roll_no, roll_no);
		String branch="";
		if(isValidRollno(roll_no)){
			switch (roll_no.substring(5, 7).toLowerCase()) {
			case "cs":
					branch="Computer Science";
				break;
			case "ec":
				branch="Electronics & Communication";
			break;
			case "ce":
				branch="Civil Engineering";
			break;
			case "me":
				branch="Mechanical Engineering";
			break;
			case "ee":
				branch="Electrical Engineering";
			break;
			case "cr":
				branch="Ceramic Engineering";
			break;
		}
			}
		
		else{
			branch="Invalid Roll number!!";
		}
		Log.d("getbranch()", branch);
		return branch;
		
	}
	public String getDepartment(String department){
		String branch="";	
		switch (department) {
		case "cse":
				branch="Computer Science";
			break;
		case "ec":
			branch="Electronics & Communication";
		break;
		case "ce":
			branch="Civil Engineering";
		break;
		case "me":
			branch="Mechanical Engineering";
		break;
		case "ee":
			branch="Electrical Engineering";
		break;
		case "cr":
			branch="Ceramic Engineering";
		break;
		}
		return branch;
	}
}
