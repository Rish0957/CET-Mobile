package com.rtupass.application;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

import com.android.volley.Request.Method;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.rtupass.application.app.AppConfig;
import com.rtupass.application.app.AppController;
import com.rtupass.application.helper.SessionManager;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class GeneratePost extends Fragment {
EditText getContent;
Button share;
SessionManager session;
String name,uid,branch,content,roll_no;
String trimed_roll_no;
private ProgressDialog pDialog;
StringOperations obj=new StringOperations();
JSONParser jParser=new JSONParser();
//private static final String TAG = GeneratePost.class.getSimpleName();

  @Override
   public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
   
          View shareView = inflater.inflate(R.layout.frag_generate_post, container, false);

          getContent=(EditText)shareView.findViewById(R.id.name);
          share=(Button)shareView.findViewById(R.id.btnPost);
          
     
          pDialog = new ProgressDialog(getActivity());
          pDialog.setCancelable(false);
    
    // Session manager
       session = new SessionManager(getActivity());
      
        // Check if user is already logged in or not
        if( !(session.isLoggedIn())) {
            Toast.makeText(getActivity(), "Please Login First",Toast.LENGTH_LONG).show();
            Intent intent = new Intent(getActivity(), MainActivity.class);
            startActivity(intent);
            getActivity().finish();
        }
        
        share.setOnClickListener(new OnClickListener() {
         
            public void onClick(View view) {
              
                 name=session.returnName();
                 uid=session.returnUid();
               roll_no=session.returnRollno();
               branch="";
        if(!roll_no.isEmpty() ){
            
            branch=obj.getBranch(roll_no);
            trimed_roll_no=roll_no.substring(0, 7);
          
        }
              Log.d("values", "name: "+name+", roll_no: "+roll_no+", uid: "+ uid +", trimmed : "+trimed_roll_no);
              
              content=getContent.getText().toString().trim();
 
                // Check for empty data in the form
                if (!trimed_roll_no.isEmpty() && !name.isEmpty() && !content.isEmpty() && !branch.isEmpty() && !uid.isEmpty()) {
                  //post data to server
                //   postStatus(name,trimed_roll_no,content,branch,uid);
                  generatePost(name,uid,trimed_roll_no,roll_no,content,branch);
                  
                } else {
                    // Prompt user to enter credentials
                    Toast.makeText(getActivity(),"Something is wrong,please login again!", Toast.LENGTH_LONG).show();
                }
            }
 
        });
    return shareView;
    
  }

  private void generatePost(final String name_,final String uid_,final String trimed_roll_no_,final String roll_no_,final String content_,final String branch_) {
      // Tag used to cancel the request
      String tag_string_req = "req_login";

      pDialog.setMessage("Sharing with your classmates...");
      showDialog();

      StringRequest strReq = new StringRequest(Method.POST,AppConfig.URL_GENERATE_POST, new Response.Listener<String>() {

          @Override
          public void onResponse(String response) {
             // Log.d(TAG, "Login Response: " + response.toString());
              hideDialog();

              try {
                  JSONObject json = new JSONObject(response);
                  boolean error = json.getBoolean("error");
				        if (!error) {

				                  String message = json.getString("message");
				                  try {
									getContent.setText(null);
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
				                  Toast.makeText(getActivity(), message, Toast.LENGTH_LONG).show();
				                    // Launch main activity
				                  
				        } else {

				          // Error occurred in posting. Get the error
				          // message
				          String errorMsg = json.getString("error_msg");
				          Toast.makeText(getActivity(),errorMsg, Toast.LENGTH_LONG).show();
				        }
	                } catch (JSONException e) {
	                    // JSON error
	                    //e.printStackTrace();
	                    Toast.makeText(getActivity(),"Something went wrong!!", Toast.LENGTH_LONG).show();
              }

          }
      }, new Response.ErrorListener() {

          @Override
          public void onErrorResponse(VolleyError error) {
              //Log.e(TAG, "Login Error: " + error.getMessage());
              //Toast.makeText(getApplicationContext(),error.getMessage(), Toast.LENGTH_LONG).show();
				Toast.makeText(getActivity(),"Uncaught Error!! ,check Internet settings.", Toast.LENGTH_LONG).show();
              hideDialog();
          }
      }) {

          @Override
          protected Map<String, String> getParams() {
              // Posting parameters to login url
              Map<String, String> params = new HashMap<String, String>();
 		        params.put("name", name_);
		        params.put("uid",uid_);
		        params.put("trimmed_roll_no", trimed_roll_no_);
		        params.put("roll_no", roll_no_);
		        params.put("content", content_);
		        params.put("branch", branch_);

              return params;
          }

      };

      // Adding request to request queue
      AppController.getInstance().addToRequestQueue(strReq, tag_string_req);
  }

  private void showDialog() {
      if (!pDialog.isShowing())
          pDialog.show();
  }

  private void hideDialog() {
      if (pDialog.isShowing())
          pDialog.dismiss();
  }	

 

  
}


//class add_data extends AsyncTask<Integer, Integer, Integer>
//{
//JSONObject json;
//@Override
//protected Integer doInBackground(Integer... param) 
//{
//  try {
//    // TODO Auto-generated method stub
//    HashMap<String, String> nameValuePairs = new HashMap<>();
//    nameValuePairs.put("name", name);
//    nameValuePairs.put("uid",uid);
//    nameValuePairs.put("trimmed_roll_no", trimed_roll_no);
//    nameValuePairs.put("roll_no", roll_no);
//    nameValuePairs.put("content", content);
//    nameValuePairs.put("branch", branch);
//    Log.d("IN background add_data=",""+nameValuePairs);
//    json = jParser.makeHttpRequest(AppConfig.URL_GENERATE_POST,"POST", nameValuePairs);
//    if (json != null) {
//        Log.d("JSON result", json.toString());
//    }
//  } catch (Exception e) {
//    // TODO Auto-generated catch block
//    e.printStackTrace();
//  }
//  return null;
//}
//@Override
//protected void onPostExecute(Integer result) 
//{
//  // TODO Auto-generated method stub
//  super.onPostExecute(result);
//  pDialog.dismiss();
//  try {
//    Log.d("JsonParser", json.toString());
//    boolean error = json.getBoolean("error");
//    if (!error) {
//
//              String message = json.getString("message");
//              Toast.makeText(getActivity(), message, Toast.LENGTH_LONG).show();
//                // Launch main activity
//                Intent intent = new Intent(getActivity(),MainActivity.class);
//                startActivity(intent);
//                getActivity().finish();
//    } else {
//
//      // Error occurred in posting. Get the error
//      // message
//      String errorMsg = json.getString("error_msg");
//      Toast.makeText(getActivity(),errorMsg, Toast.LENGTH_LONG).show();
//    }
//  } catch (JSONException e) {
//    e.printStackTrace();
//  }
//  
//}
//@Override
//protected void onPreExecute() 
//{
//  // TODO Auto-generated method stub
//  super.onPreExecute();
//  pDialog.setMessage("Sharing this with your friends...");
//  pDialog.show();
//    
//
//}
//
//} 

