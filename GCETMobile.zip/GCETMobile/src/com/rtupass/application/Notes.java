package com.rtupass.application;

import java.util.ArrayList;

import com.rtupass.application.Lab.ViewDialog;
import com.rtupass.application.helper.SessionManager;

import android.app.Activity;
import android.app.Dialog;
import android.app.ActionBar.LayoutParams;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class Notes extends Fragment {
	ListView list;
	TextView heading;
	SQLiteDatabase database;
	public ArrayList<String> sub_name,sub_syllabus;
	private String DB_NAME="college.db";
	String sem,branch;
	ViewDialog alert;
	ArrayAdapter<String> listAdapter;
	@Override
	    public View onCreateView(LayoutInflater inflater, ViewGroup container,
	            Bundle savedInstanceState) {
	 
	        View notes = inflater.inflate(R.layout.notes_frag, container, false);
	        list=(ListView)notes.findViewById(R.id.listView1);
	        sem=new SessionManager(getActivity()).returnSem();
	        branch=new SessionManager(getActivity()).returnBranch();
	        alert = new ViewDialog();
	        heading=(TextView)notes.findViewById(R.id.textView1);
	        heading.setText(sem+" Syllabus");
	        
	        database=getActivity().openOrCreateDatabase(DB_NAME, Context.MODE_PRIVATE,null);
	        try {
				sub_name=new ArrayList<String>();
				sub_syllabus=new ArrayList<String>();
				String query= "select subject_name,syllabus from notes l INNER JOIN semester s ON l.sem_id=s.sem_id "
						+ "INNER JOIN department d ON d.department_id=s.dept_id ";
				query+="where department_name='"+branch+"' and sem_name='"+sem+"' order by l.id asc";
				Cursor c=database.rawQuery(query, null);
				c.moveToFirst();
				if(!c.isAfterLast()) {
					do {
						String name = c.getString(0);
						String syllabus=c.getString(1);
						Log.d("name", name);
						sub_name.add(name);
						sub_syllabus.add(syllabus);
					} while (c.moveToNext());
				}
				c.close();
				listAdapter=new ArrayAdapter<>(getActivity(),android.R.layout.simple_list_item_1, sub_name);
				list.setAdapter(listAdapter);
				
				list.setOnItemClickListener(new OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
						// TODO Auto-generated method stub
						alert.showDialogue(getActivity(),sub_name.get(arg2),"80 + 20",sub_syllabus.get(arg2));
					}
				});
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	       database.close();
	        
	        return notes;
 }
	public class ViewDialog{
		public void showDialogue(Activity activity,final String string,final  String string2,final String string3) {
			// TODO Auto-generated method stub
			 final Dialog dialog = new Dialog(activity);
		        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		        dialog.setCancelable(true);
		        dialog.setContentView(R.layout.lab_description_dialogue);
		        
		        
			TextView heading_name=(TextView)dialog.findViewById(R.id.lab_name);
			TextView mrks=(TextView)dialog.findViewById(R.id.textView3);
			Button ok=(Button)dialog.findViewById(R.id.button1);
			final TextView content=(TextView)dialog.findViewById(R.id.textView4);
			
			heading_name.setText(string);
			mrks.setText(string2);
			content.setText(string3);
			ok.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					dialog.dismiss();
				}
			});
			
		
		
			dialog.show();
			Window window = dialog.getWindow();
			window.setLayout(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
		
			
		}
	}
}













//try {
//	sub_name=new ArrayList<String>();
//	String query= "SELECT department_name FROM ";
//	Cursor c=database.rawQuery(query, null);
//	c.moveToFirst();
//	if(!c.isAfterLast()) {
//		do {
//			String name = c.getString(0);
//			sub_name.add(name);
//		} while (c.moveToNext());
//	}
//	c.close();
//	listAdapter=new ArrayAdapter<>(getActivity(),android.R.layout.simple_spinner_dropdown_item, sub_name);
//} catch (Exception e) {
//	// TODO Auto-generated catch block
//	e.printStackTrace();
//}