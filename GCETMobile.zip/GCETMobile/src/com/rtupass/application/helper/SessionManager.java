package com.rtupass.application.helper;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.util.Log;

public class SessionManager {
	 // LogCat tag
    private static String TAG = SessionManager.class.getSimpleName();
 
    // Shared Preferences
    SharedPreferences pref;
 
    Editor editor;
    Context _context;
 
    // Shared pref mode
    int PRIVATE_MODE = 0;
 
    // Shared preferences file name
    private static final String PREF_NAME = "GCETLogin";
     
    private static final String KEY_IS_LOGGEDIN = "isLoggedIn";
    private static final String KEY_IS_Teacher_LOGGEDIN = "isTeacherLoggedIn";
    private static final String KEY_Name = "Name";
    private static final String KEY_Email = "Email";
    private static final String KEY_Roll_no = "Roll_no";
    private static final String KEY_Unique_id = "UniqueId";
    private static final String KEY_Department = "Department";
    private static final String KEY_Designation = "Designation";
    
   
    public SessionManager(Context context) {
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }
    
    public void setLogin(boolean isLoggedIn,String name,String email,String roll_no,String uid,String branch) {
 
        editor.putBoolean(KEY_IS_LOGGEDIN, isLoggedIn);
        editor.putString(KEY_Name, name);
        editor.putString(KEY_Email, email);
        editor.putString(KEY_Roll_no, roll_no);
        editor.putString(KEY_Unique_id, uid);
        editor.putString("branch", branch);
 
        // commit changes
        editor.commit();
 
        Log.d(TAG, "User login session modified!");
    }
    public void setLogin(boolean isLoggedIn, String name,String designation,String department){
    	 editor.putBoolean(KEY_IS_LOGGEDIN, isLoggedIn);
         editor.putString(KEY_Name, name);
         editor.putBoolean(KEY_IS_Teacher_LOGGEDIN, isLoggedIn);
         editor.putString(KEY_Department, department);
         editor.putString(KEY_Designation, designation);
      // commit changes
         editor.commit();
  
         Log.d(TAG, "Teacher login session modified!");
    }
     
    public boolean isLoggedIn(){
    	if(!pref.contains(KEY_IS_LOGGEDIN)){
    		editor.putBoolean(KEY_IS_LOGGEDIN, false);
    		editor.commit();
    	}
        return pref.getBoolean(KEY_IS_LOGGEDIN, false);
    }
    public boolean isTeacherLoggedIn(){
    	if(!pref.contains(KEY_IS_Teacher_LOGGEDIN)){
    		editor.putBoolean(KEY_IS_Teacher_LOGGEDIN, false);
    	}
    	return pref.getBoolean(KEY_IS_Teacher_LOGGEDIN, false);
    }
    public void clearSharedPreferences(){
    	//clears Shared Prefrences
    	editor.clear();
    	editor.commit();
    }
    public void studyMaterial(String sem,String branch){
    	
    	editor.putString("sem_name", sem);
    	editor.putString("branch_name",branch);
    	editor.commit();
    }
    public String returnSem(){
    	if(!pref.contains("sem_name")){
    		editor.putString("sem_name","Ist Sem");
    		editor.commit();
    	}
    	String sem=pref.getString("sem_name", "Ist Sem");
    	return sem;
    }
    public String returnBranch(){
//this function is for study material
    	if(!pref.contains("branch_name")){
    		editor.putString("branch_name", "Computer Science");
    		editor.commit();
    	}
    	return pref.getString("branch_name", "Computer Science");
    }
    public String getBranch(){
    	//this function is for Notification Activity
    	    	
    	    	return pref.getString("branch", "Computer Science");
    	    }
    
    public String returnName(){
    	return pref.getString(KEY_Name,"user");
    }
    public String returnDepartment(){
    	return pref.getString(KEY_Department,"Computer Science");
    }
    public String returnDesignation(){
    	return pref.getString(KEY_Designation,"Assistant Professor");
    }
    public String returnRollno(){
    	return pref.getString(KEY_Roll_no,"default");
    }
    public String returnUid(){
    	return pref.getString(KEY_Unique_id,"default");
    }

	public void placementCorner(String selected_company) {
		editor.putString("company_name",selected_company);
		editor.commit();
	}
	public String getCompany(){
		if(!pref.contains("company_name")){
			editor.putString("company_name","Tata Consultancy Services (TCS)");
			editor.commit();
		}
		return pref.getString("company_name", "Tata Consultancy Services (TCS)");
	}

}
