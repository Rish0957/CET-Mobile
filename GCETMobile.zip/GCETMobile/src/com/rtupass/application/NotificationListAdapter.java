package com.rtupass.application;

import java.util.List;

import LruBitmapCache.NotificationItem;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class NotificationListAdapter  extends BaseAdapter {  
    private Context activity;
    private LayoutInflater inflater;
    private List<NotificationItem> feedItems;
//    ImageLoader imageLoader = AppController.getInstance().getImageLoader();
 
    public NotificationListAdapter(Context activity, List<NotificationItem> feedItems) {
        this.activity = activity;
        this.feedItems = feedItems;
    }
 
    @Override
    public int getCount() {
        return feedItems.size();
    }
 
    @Override
    public Object getItem(int location) {
        return feedItems.get(location);
    }
 
    @Override
    public long getItemId(int position) {
        return position;
    }
 
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
 
        if (inflater == null)
            inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null)
            convertView = inflater.inflate(R.layout.notification_item, null);
 
        TextView name = (TextView) convertView.findViewById(R.id.name);
        TextView branch = (TextView) convertView.findViewById(R.id.branch);
        TextView timestamp = (TextView) convertView.findViewById(R.id.timestamp);
        TextView content = (TextView) convertView.findViewById(R.id.content);
 
        NotificationItem item = feedItems.get(position);
 
        name.setText(item.getName());
        branch.setText(item.getBranch());
        timestamp.setText(item.getTimeStamp());
        content.setText(item.getContent());
 
 
        return convertView;
    }
 
}

