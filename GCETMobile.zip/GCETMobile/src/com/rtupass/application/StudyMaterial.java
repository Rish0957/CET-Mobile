package com.rtupass.application;

import java.util.ArrayList;

import com.rtupass.application.helper.SessionManager;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class StudyMaterial extends Activity{
	Spinner spinner_b,spinner_sem;
	Button home,letsGo;
	private static final String DB_NAME = "college.db";
	private static final String TABLE_NAME_SEMESTER = "semester";
	private static final String TABLE_NAME_DEPARTMENT = "department";
	String selected_brach,selected_sem;
	private SQLiteDatabase database;
	private ArrayList<String> branches,semesters;
	ArrayAdapter<String>branch_adapter,sem_adapter;
	SessionManager session;
	ActionBar actionBar;
		
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_study_material);
	
		actionBar=getActionBar();
		actionBar.hide();
		ExternalDbOpenHelper dbOpenHelper = new ExternalDbOpenHelper(this, DB_NAME);
        database = dbOpenHelper.openDataBase();
        dbOpenHelper.close();
		spinner_b=(Spinner)findViewById(R.id.branch);
		spinner_sem=(Spinner)findViewById(R.id.semester);
		letsGo=(Button)findViewById(R.id.btnLetsGo);
		home=(Button)findViewById(R.id.btnBackToHome);
		
		session = new SessionManager(getApplicationContext());
		
		
        database= openOrCreateDatabase(DB_NAME, Context.MODE_PRIVATE, null);
        createSemesterAdapter();
        createBranchAdapter();
        database.close();
        spinner_sem.setAdapter(sem_adapter);
        Log.d("SEM adapter","Adapter Set");
        Log.d("Values", semesters.get(1).toString());
        //spinner_sem.setOnItemSelectedListener(this);
        spinner_b.setAdapter(branch_adapter);
       // spinner_b.setOnItemSelectedListener(this);
        spinner_sem.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
				// TODO Auto-generated method stub
				selected_sem=arg0.getItemAtPosition(arg2).toString();
				
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
        	
		});
        spinner_b.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

		@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
				// TODO Auto-generated method stub
				selected_brach=arg0.getItemAtPosition(arg2).toString();
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
        	
		});
        
        letsGo.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(!selected_brach.equals(branches.get(0)) && !selected_sem.equals(semesters.get(0))){
		        	session.studyMaterial(selected_sem, selected_brach);
		        	Intent i=new Intent(StudyMaterial.this,TabActivity.class);
		        	startActivity(i);
		        }
				else{
					Toast.makeText(getApplicationContext(), "Please select both branch and semester!!", Toast.LENGTH_LONG).show();
				}
			}
		});
        home.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i=new Intent(StudyMaterial.this,MainActivity.class);
				startActivity(i);
				finish();
			}
		});
	}
	private void createBranchAdapter(){
		branches=new ArrayList<String>();
//		String query= "SELECT department_name FROM "+TABLE_NAME_DEPARTMENT;
//		Cursor c=database.rawQuery(query, null);
//		c.moveToFirst();
//		if(!c.isAfterLast()) {
//			do {
//				String name = c.getString(0);
//				branches.add(name);
//			} while (c.moveToNext());
//		}
//		c.close();
		branches.add("----Select Branch----");
		branches.add("Computer Science Engineering");
		branch_adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item, branches){
			 @Override
		     public View getDropDownView(int position, View convertView, ViewGroup parent) {
		         View view = super.getDropDownView(position, convertView, parent);
		        

		         // If this is the initial dummy entry, make it hidden
		         if (position == 0) {
		             TextView tv = new TextView(getContext());
		             tv.setHeight(0);
		             tv.setVisibility(View.GONE);
		             view = tv;
		         }
		         else {
		             // Pass convertView as null to prevent reuse of special case views
		             view = super.getDropDownView(position, null, parent);
		         }

		         // Hide scroll bar because it appears sometimes unnecessarily, this does not prevent scrolling 
		         parent.setVerticalScrollBarEnabled(false);
		         return view;
		     }
		 };
		}
		
	private void createSemesterAdapter(){
		Log.d("Creating sem Adapter", "creating");
		semesters=new ArrayList<String>();
		semesters.add("----Select Semester----");
		String query= "SELECT sem_name FROM "+TABLE_NAME_SEMESTER+" WHERE dept_id='cse' ";
		Cursor c=database.rawQuery(query, null);
		c.moveToFirst();
		if(!c.isAfterLast()) {
			do {
				String name = c.getString(0);
				semesters.add(name);
			} while (c.moveToNext());
		}
		c.close();
		sem_adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item, semesters){
			@Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
               

                // If this is the initial dummy entry, make it hidden
                if (position == 0) {
                    TextView tv = new TextView(getContext());
                    tv.setHeight(0);
                    tv.setVisibility(View.GONE);
                    view = tv;
                   
                }
                else {
                    // Pass convertView as null to prevent reuse of special case views
                    view = super.getDropDownView(position, null, parent);
                }

                // Hide scroll bar because it appears sometimes unnecessarily, this does not prevent scrolling 
                parent.setVerticalScrollBarEnabled(false);
                return view;
            }
        };	
				
		Log.d("exiting Create Sem Adapter","Exiting");
	}


}
