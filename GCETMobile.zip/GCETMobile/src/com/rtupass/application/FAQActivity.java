package com.rtupass.application;

import java.util.ArrayList;

import android.app.ActionBar;
import android.app.ActionBar.LayoutParams;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

public class FAQActivity extends Activity {
	ActionBar ab;
	SQLiteDatabase database;
	private static final String DB_NAME="college.db";
	ListView question_list;
	ArrayList<String> questions,answers;
	ViewDialogFAQ alert;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_faq);
		
		 alert=new ViewDialogFAQ();
		 
		ab=getActionBar();
		ab.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#000000")));
        ab.setIcon(new ColorDrawable(getResources().getColor(android.R.color.transparent)));
        ab.setTitle("  Frequently Asked Questions");
        
        question_list=(ListView)findViewById(R.id.listViewFAQ);
        database=openOrCreateDatabase(DB_NAME, Context.MODE_PRIVATE,null);
        //////////////////////////////////////////////////////////////////////////////////////////////////////////
		//////////////---For Police Stations//////////////////////////////////////////////////////////////////////
		try {
			questions=new ArrayList<String>();
			answers=new ArrayList<String>();
		String query= "select question,answer from faq" ;
			Cursor c=database.rawQuery(query, null);
			c.moveToFirst();
			if(!c.isAfterLast()) {
				do {
					String ques = c.getString(0);
					String ans=c.getString(1);
					
					questions.add(ques);
					answers.add(ans);
				} while (c.moveToNext());
			}
			c.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		question_list.setAdapter(new ArrayAdapter<String>(FAQActivity.this,android.R.layout.simple_list_item_1,questions));
		question_list.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				// TODO Auto-generated method stub
				alert.showDialogue(FAQActivity.this,questions.get(position),answers.get(position));
			}
		});
		
		
	}
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		//super.onBackPressed();
		//Toast.makeText(getApplicationContext(), "You pressed back.", Toast.LENGTH_SHORT).show();
		startActivity(new Intent(FAQActivity.this,HelpActivity.class));
		finish();	
	
	}
	public class ViewDialogFAQ{
		public void showDialogue(Context activity,final String string,final String string3) {
			// TODO Auto-generated method stub
			 final Dialog dialog = new Dialog(activity);
		        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		        dialog.setCancelable(true);
		        dialog.setContentView(R.layout.lab_description_dialogue);
		        
		        
			TextView heading_name=(TextView)dialog.findViewById(R.id.lab_name);
			LinearLayout linear=(LinearLayout) dialog.findViewById(R.id.linearmarks);
			Button ok=(Button)dialog.findViewById(R.id.button1);
			final TextView content=(TextView)dialog.findViewById(R.id.textView4);
			
			linear.setVisibility(View.GONE);
			heading_name.setText(string);
			content.setText(string3);
			ok.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					dialog.dismiss();
				}
			});
			
			dialog.show();
			Window window = dialog.getWindow();
			window.setLayout(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
		
			
		}
	}
	
}
