package com.rtupass.application;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

public class DashBoardPagerAdapter extends FragmentStatePagerAdapter {
    public DashBoardPagerAdapter(FragmentManager fm) {
		// TODO Auto-generated constructor stub
		super(fm);
	}

	@Override
	public Fragment getItem(int i) {
		switch (i) {
        case 0:
            //Fragment for profile
        	return new Profile();
        case 1:
           //Fragment for sharing information
            return new GeneratePost();
        case 2:
            //Fragment for feeds
        	return new StudentPost();
            
        case 3:
            //Fragment for friends list
            return new Friends();
        }
		return null;
		
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return 4; //No of Tabs
	}


    }