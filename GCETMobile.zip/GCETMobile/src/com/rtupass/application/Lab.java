package com.rtupass.application;

import java.util.ArrayList;

import com.rtupass.application.helper.SessionManager;

import android.app.ActionBar.LayoutParams;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class Lab extends Fragment {
	ListView List;
	SQLiteDatabase database;
	TextView heading;
	public ArrayList<String> lab_name;
	public ArrayList<String> marks,description;
	private String DB_NAME="college.db";
	String sem,branch;
	ViewDialog alert;
	ArrayAdapter<String> listAdapter;
	 @Override
	    public View onCreateView(LayoutInflater inflater, ViewGroup container,
	            Bundle savedInstanceState) {
	 
		    View lab = inflater.inflate(R.layout.lab_frag, container, false);
		    List=(ListView)lab.findViewById(R.id.expandableListView1);
		    sem=new SessionManager(getActivity()).returnSem();
	        branch=new SessionManager(getActivity()).returnBranch();
	        heading=(TextView)lab.findViewById(R.id.textView1);
	        alert = new ViewDialog();
	        heading.setText(sem+" Lab Subjects");
	       
	        database=getActivity().openOrCreateDatabase(DB_NAME, Context.MODE_PRIVATE,null);
	        try {
				lab_name=new ArrayList<String>();
				marks=new ArrayList<String>();
				description=new ArrayList<String>();
			String query= "select lab_name,marks,description from lab l INNER JOIN semester s ON l.sem_id=s.sem_id "
					+ "INNER JOIN department d ON d.department_id=s.dept_id ";
			query+="where department_name='"+branch+"' and sem_name='"+sem+"' order by l.marks asc";
				Cursor c=database.rawQuery(query, null);
				c.moveToFirst();
				if(!c.isAfterLast()) {
					do {
						String name = c.getString(0);
						String mark=c.getString(1);
						String LabDescription=c.getString(2);
						lab_name.add(name);
						marks.add(mark);
						description.add(LabDescription);
					} while (c.moveToNext());
				}
				c.close();
				listAdapter=new ArrayAdapter<>(getActivity(),android.R.layout.simple_list_item_1, lab_name);
				List.setAdapter(listAdapter);
				List.setOnItemClickListener(new AdapterView.OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
						// TODO Auto-generated method stub
						Log.d("dialog values",lab_name.get(arg2)+", "+marks.get(arg2)+", "+description.get(arg2));						
						alert.showDialogue(getActivity(),lab_name.get(arg2),marks.get(arg2),description.get(arg2));
						//Toast.makeText(getActivity(), marks.get(arg2), Toast.LENGTH_SHORT).show();
					}
				});
				
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	       database.close();
	        
	        return lab;
}
	public class ViewDialog{
		public void showDialogue(Activity activity,final String string,final  String string2,final String string3) {
			// TODO Auto-generated method stub
			 final Dialog dialog = new Dialog(activity);
		        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		        dialog.setCancelable(true);
		        dialog.setContentView(R.layout.lab_description_dialogue);
		        
		        
			TextView heading_name=(TextView)dialog.findViewById(R.id.lab_name);
			TextView mrks=(TextView)dialog.findViewById(R.id.textView3);
			Button ok=(Button)dialog.findViewById(R.id.button1);
			final TextView content=(TextView)dialog.findViewById(R.id.textView4);
			
			heading_name.setText(string);
			mrks.setText(string2);
			content.setText(string3);
			ok.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					dialog.dismiss();
				}
			});
			
		
		
			dialog.show();
			Window window = dialog.getWindow();
			window.setLayout(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
		
			
		}
	}
	
}
