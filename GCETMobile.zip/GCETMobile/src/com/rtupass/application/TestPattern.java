package com.rtupass.application;

import java.util.ArrayList;

import com.rtupass.application.helper.SessionManager;

import android.app.ActionBar.LayoutParams;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

public class TestPattern extends Fragment {
	ListView list;
	SQLiteDatabase database;
	public ArrayList<String> selection_process,description;
	private String DB_NAME="college.db";
	String company_name;
	ViewDialogTest alert;
	ArrayAdapter<String> listAdapter;
	@Override
	    public View onCreateView(LayoutInflater inflater, ViewGroup container,
	            Bundle savedInstanceState) {
	 
	        View notes = inflater.inflate(R.layout.placement_pattern, container, false);
	        list=(ListView)notes.findViewById(R.id.listView1);
	        alert = new ViewDialogTest();
	        company_name=new SessionManager(getActivity()).getCompany();
	        Log.d("company_name", company_name);
	        
	        database=getActivity().openOrCreateDatabase(DB_NAME, Context.MODE_PRIVATE,null);
	        try {
				selection_process=new ArrayList<String>();
				description=new ArrayList<String>();
			String query= "select t.name,t.description from test_pattern t INNER JOIN company c ON t.company_id=c.id ";
			query+="where company_name='"+company_name+"' order by t.id asc";
				Cursor c=database.rawQuery(query, null);
				c.moveToFirst();
				if(!c.isAfterLast()) {
					do {
						String name = c.getString(0);
						String pattern_description=c.getString(1);
						selection_process.add(name);
						
						description.add(pattern_description);
					} while (c.moveToNext());
					Log.d("value is being inserted",selection_process.get(0));
				}
				Log.d("Row found :", "none");
				c.close();
				listAdapter=new ArrayAdapter<>(getActivity(),android.R.layout.simple_list_item_1, selection_process);
				list.setAdapter(listAdapter);
				list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
						// TODO Auto-generated method stub						
						alert.showDialogue(getActivity(),selection_process.get(arg2),description.get(arg2));
			
					}
				});
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	       database.close();
	        
	        return notes;
}
	public class ViewDialogTest{
		public void showDialogue(Activity activity,final String string,final String string3) {
			// TODO Auto-generated method stub
			 final Dialog dialog = new Dialog(activity);
		        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		        dialog.setCancelable(true);
		        dialog.setContentView(R.layout.lab_description_dialogue);
		        
		        
			TextView heading_name=(TextView)dialog.findViewById(R.id.lab_name);
			LinearLayout linear=(LinearLayout) dialog.findViewById(R.id.linearmarks);
			Button ok=(Button)dialog.findViewById(R.id.button1);
			final TextView content=(TextView)dialog.findViewById(R.id.textView4);
			
			linear.setVisibility(View.GONE);
			heading_name.setText(string);
			content.setText(string3);
			ok.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					dialog.dismiss();
				}
			});
			
			dialog.show();
			Window window = dialog.getWindow();
			window.setLayout(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
		
			
		}
	}}
