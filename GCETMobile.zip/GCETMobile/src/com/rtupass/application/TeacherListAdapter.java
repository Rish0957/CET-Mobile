package com.rtupass.application;

import java.util.ArrayList;
import java.util.List;

import com.android.volley.toolbox.NetworkImageView;

import LruBitmapCache.TeacherDirectoryItem;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

public class TeacherListAdapter  extends BaseAdapter implements Filterable {  
    private Context activity;
    private LayoutInflater inflater;
    private List<TeacherDirectoryItem> feedItems;
    private List<TeacherDirectoryItem> mStringFilterList;
    ValueFilter valueFilter;
//    ImageLoader imageLoader = AppController.getInstance().getImageLoader();
 
    public TeacherListAdapter(Context activity, List<TeacherDirectoryItem> feedItems) {
        this.activity = activity;
        this.feedItems = feedItems;
        this.mStringFilterList=feedItems;
    }
 
    @Override
    public int getCount() {
        return feedItems.size();
    }
 
    @Override
    public Object getItem(int location) {
        return feedItems.get(location);
    }
 
    @Override
    public long getItemId(int position) {
        return position;
    }
 
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
 
        if (inflater == null)
            inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null)
            convertView = inflater.inflate(R.layout.teacher_item, null);
 
//        if (imageLoader == null)
//            imageLoader = AppController.getInstance().getImageLoader();
 
        TextView name = (TextView) convertView.findViewById(R.id.name);
        TextView branch = (TextView) convertView.findViewById(R.id.branch);
        TextView designation = (TextView) convertView.findViewById(R.id.designation);
        TextView qualification = (TextView) convertView.findViewById(R.id.qualification);
        TextView email = (TextView) convertView.findViewById(R.id.email);
        TextView phone = (TextView) convertView.findViewById(R.id.phone);
        NetworkImageView profilePic = (NetworkImageView) convertView.findViewById(R.id.profilePic);
 
        TeacherDirectoryItem item = feedItems.get(position);
 
        name.setText(item.getName());
        designation.setText(item.getDesignation());
        qualification.setText(item.getQualification());

         // Checking for null phone number
        if (item.getPhone() != null) {
            phone.setText(item.getPhone());
        } else {
            // url is null, remove from the view
            phone.setText("Not Available");
        }
         // Checking for null email
        if (item.getEmail() != null) {
            email.setText(item.getEmail());
        } else {
            // url is null, remove from the view
            email.setText("Not Available");
        }
 
 
        // Checking for null feed url
        if (item.getBranch() != null) {
          branch.setText(item.getBranch());
            branch.setVisibility(View.VISIBLE);
        } else {
            // url is null, remove from the view
            branch.setVisibility(View.GONE);
        }
 
        // user profile pic
//        profilePic.setImageUrl(item.getProfilePic(), imageLoader);
 
 
        return convertView;
    }

	@Override
	public Filter getFilter() {
		// TODO Auto-generated method stub
		   if (valueFilter == null) {
	            valueFilter = new ValueFilter();
	        }
	        return valueFilter;
	}
	private class ValueFilter extends Filter {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();

            if (constraint != null && constraint.length() > 0) {
                List<TeacherDirectoryItem> filterList = new ArrayList<TeacherDirectoryItem>();
                for (int i = 0; i < mStringFilterList.size(); i++) {
                    if ( (mStringFilterList.get(i).getName().toUpperCase() ).contains(constraint.toString().toUpperCase())) {

                        TeacherDirectoryItem item = new TeacherDirectoryItem(mStringFilterList.get(i).getId(),
                        		mStringFilterList.get(i).getName() ,
                        		mStringFilterList.get(i).getQualification() ,
                        		mStringFilterList.get(i).getDesignation(),
                        		mStringFilterList.get(i).getEmail(),
                        		mStringFilterList.get(i).getPhone(),
                        		mStringFilterList.get(i).getBranch()
                        		);

                        filterList.add(item);
                    }
                }
                results.count = filterList.size();
                results.values = filterList;
            } else {
                results.count = mStringFilterList.size();
                results.values = mStringFilterList;
            }
            return results;

        }

        @Override
        protected void publishResults(CharSequence constraint,
                FilterResults results) {
            feedItems = (ArrayList<TeacherDirectoryItem>) results.values;
            notifyDataSetChanged();
        }

    }
 
}

