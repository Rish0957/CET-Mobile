package com.rtupass.application;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

import com.android.volley.Request.Method;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.rtupass.application.app.AppConfig;
import com.rtupass.application.app.AppController;
import com.rtupass.application.helper.SessionManager;

import android.app.ActionBar;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Enquiry extends Activity {
	ActionBar ab;
	private ProgressDialog pDialog;
	SessionManager session;
	EditText et_name,et_mobile,et_email,et_query,et_remark;
	Button btn_enquire;
	String name,uid,mobile,email,query,remark;
	String UserName;
	String error_validations;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_enquiry);
		
		session=new SessionManager(getApplicationContext());
		
		// Progress dialog
			pDialog = new ProgressDialog(this);
			pDialog.setCancelable(false);
		
		ab=getActionBar();
		ab.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#000000")));
        ab.setIcon(new ColorDrawable(getResources().getColor(android.R.color.transparent)));
        ab.setTitle(" Enquiry");
        
        //fetching name of user
        UserName=session.returnName();
        
        et_name=(EditText)findViewById(R.id.name);
        et_mobile=(EditText)findViewById(R.id.mobile);
        et_email=(EditText)findViewById(R.id.email);
        et_query=(EditText)findViewById(R.id.query);
        et_remark=(EditText)findViewById(R.id.remark);
        btn_enquire=(Button)findViewById(R.id.btn_enquire);
        
        btn_enquire.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				 name = et_name.getText().toString().trim();
			 	 email =et_email.getText().toString().trim();
				 mobile =et_mobile.getText().toString().trim();
				 query=et_query.getText().toString().trim();
				 remark=et_remark.getText().toString().trim();
				 uid=session.returnUid();
				
				if (!name.isEmpty() && !email.isEmpty() && !mobile.isEmpty() && !query.isEmpty() ) {
					if(validation(name,email,mobile,query)){
						submitQuery(name,email,mobile,query,remark,uid); 
					}
					else{
						Toast.makeText(getApplicationContext(), error_validations, Toast.LENGTH_LONG).show();
					}
				} else {
					Toast.makeText(getApplicationContext(),"Please fill all entries.", Toast.LENGTH_LONG).show();
				}
			}
			
		});
        
        
	}
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		//super.onBackPressed();
		//Toast.makeText(getApplicationContext(), "You pressed back.", Toast.LENGTH_SHORT).show();
		startActivity(new Intent(Enquiry.this,HelpActivity.class));
		finish();	
	
	}
//---------------------------------------------------------------------------------------------------------------------------------------
	private boolean validation(String name,String email,String phone,String query){
		boolean no_error=true;
		int aa=Integer.parseInt(phone.substring(0,1));
		String EMAIL_REGEX = "^[\\w-_\\.+]*[\\w-_\\.]\\@gmail.com";
		Log.d("Email", email);
		Log.d("Matches? -->", email.matches(EMAIL_REGEX)+"");
		
		if(!(phone.length()==10)){
			error_validations="Please enter a 10 digit mobile number!";
			no_error=false;
		}
		
		if(phone.length()==10){
			switch (aa) {
			case 9:
				no_error=true;
				break;
			case 8:
				no_error=true;
				break;
			case 7:
				no_error=true;
				break;

			default:
				error_validations="Invalid mobile number.";
				no_error=false;
				break;
			}
		}
		if(name.length()<7){
			error_validations="Enter your full name.";
			no_error=false;
		}
		if(query.length()<20){
			error_validations="Please enter a genuine query!";
			no_error=false;
		}
		if(!(email.matches(EMAIL_REGEX))){
			no_error=false;
			error_validations="Please provide your Gmail Id!!";
		}
	
		return no_error;
	}
//---------------------------------------------------------------------------------------------------------------------------------------
//------vollley request----submit query----submitQuery(name,email,mobile,query,remark,uid);
	private void submitQuery(final String name_, final String email_,final String mobile_,final String query_,final String remark_,final String uid_) {
		// Tag used to cancel the request
		String tag_string_req = "req_query";

		pDialog.setMessage("Please wait...");
		showDialog();

		StringRequest strReq = new StringRequest(Method.POST,AppConfig.URL_Enquiry, new Response.Listener<String>() {

			@Override
			public void onResponse(String response) {
				//Log.d(TAG, "Register Response: " + response.toString());
				hideDialog();

				try {
					JSONObject json = new JSONObject(response);
	                  boolean error = json.getBoolean("error");
					        if (!error) {

					                  String message = json.getString("message");

					                  Toast.makeText(getApplicationContext(), message+" Thankyou "+UserName, Toast.LENGTH_LONG).show();
					                    // Launch main activity
					                  startActivity(new Intent(Enquiry.this,HelpActivity.class));
					                  finish();
					                  
					        } else {

					          // Error occurred in posting. Get the error
					          // message
					          String errorMsg = json.getString("error_msg");
					          Toast.makeText(getApplicationContext(),errorMsg, Toast.LENGTH_LONG).show();
					        }
				} catch (JSONException e) {
					e.printStackTrace();
					Toast.makeText(getApplicationContext(),"Unknown Error occured!", Toast.LENGTH_LONG).show();
				}

			}
		}, new Response.ErrorListener() {

			@Override
			public void onErrorResponse(VolleyError error) {
				//Log.e(TAG, "Registration Error: " + error.getMessage());
				Toast.makeText(getApplicationContext(),"Network Error!!", Toast.LENGTH_LONG).show();
				hideDialog();
			}
		}) {

			@Override
			protected Map<String, String> getParams() {
				// Posting params to register url
				Map<String, String> params = new HashMap<String, String>();
				params.put("name", name_);
				params.put("email", email_);
				params.put("mobile",mobile_);
				params.put("student_query", query_);
				params.put("uid", uid_);
				params.put("remark",remark_);

				return params;
			}

		};

		// Adding request to request queue
		AppController.getInstance().addToRequestQueue(strReq, tag_string_req);
	}
	private void showDialog() {
		if (!pDialog.isShowing())
			pDialog.show();
	}

	private void hideDialog() {
		if (pDialog.isShowing())
			pDialog.dismiss();
	}
}
