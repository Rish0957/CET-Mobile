package com.rtupass.application;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

import com.android.volley.Request.Method;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.rtupass.application.app.AppConfig;
import com.rtupass.application.app.AppController;
import com.rtupass.application.helper.SessionManager;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class GenerateNotification extends Fragment {
EditText getContent;
Button share;
SessionManager session;
String name,branch,content,designation;
private ProgressDialog pDialog;
JSONParser jParser=new JSONParser();

  @Override
   public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
   
          View shareView = inflater.inflate(R.layout.frag_generate_notification, container, false);

          getContent=(EditText)shareView.findViewById(R.id.name);
          share=(Button)shareView.findViewById(R.id.btnPost);
          
     
     pDialog = new ProgressDialog(getActivity());
       pDialog.setCancelable(false);


       session = new SessionManager(getActivity());
      
        // Check if user is already logged in or not
        if( !(session.isTeacherLoggedIn())) {
            Toast.makeText(getActivity(), "Something went wrong. Please Login Again.",Toast.LENGTH_LONG).show();
        }
        
        share.setOnClickListener(new OnClickListener() {
         
            public void onClick(View view) {
              
                 name=session.returnName();
                 branch=session.returnDepartment();
                 designation=session.returnDesignation();
              
              content=getContent.getText().toString().trim();
 
                // Check for empty data in the form
                if (!name.isEmpty() && !branch.isEmpty() && !content.isEmpty() && !designation.isEmpty() ) {
                  //post data to server
                //   postStatus(name,trimed_roll_no,content,branch,uid);
                 generatePost(name, designation, content, branch);
                  
                } else {
                    // Prompt user to enter credentials
                    Toast.makeText(getActivity(),"Something is wrong,please try again!", Toast.LENGTH_LONG).show();
                }
            }
 
        });
    return shareView;
    
  }
  private void generatePost(final String _name,final String _designation,final String _content,final String _branch) {
      // Tag used to cancel the request
      String tag_string_req = "req_login";

      pDialog.setMessage("Sharing this with students of your department...");
      showDialog();

      StringRequest strReq = new StringRequest(Method.POST,AppConfig.URL_GENERATE_Notification, new Response.Listener<String>() {

          @Override
          public void onResponse(String response) {
             // Log.d(TAG, "Login Response: " + response.toString());
              hideDialog();

              try {
                  JSONObject json = new JSONObject(response);
                  boolean error = json.getBoolean("error");
				        if (!error) {

				                   String message = json.getString("message");
				                   try {
									getContent.setText(null);
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
				                  Toast.makeText(getActivity(), message, Toast.LENGTH_LONG).show();
				                   
				        } else {

				          // Error occurred in posting. Get the error
				          // message
				          String errorMsg = json.getString("error_msg");
				          Toast.makeText(getActivity(),errorMsg, Toast.LENGTH_LONG).show();
				        }
	                } catch (JSONException e) {
	                    // JSON error
	                    //e.printStackTrace();
	                    Toast.makeText(getActivity(),"Something went wrong!!", Toast.LENGTH_LONG).show();
              }

          }
      }, new Response.ErrorListener() {

          @Override
          public void onErrorResponse(VolleyError error) {
              //Log.e(TAG, "Login Error: " + error.getMessage());
              //Toast.makeText(getApplicationContext(),error.getMessage(), Toast.LENGTH_LONG).show();
				Toast.makeText(getActivity(),"Uncaught Error!! ,check Internet settings.", Toast.LENGTH_LONG).show();
              hideDialog();
          }
      }) {

          @Override
          protected Map<String, String> getParams() {
              // Posting parameters to login url
              Map<String, String> params = new HashMap<String, String>();
 		        params.put("name", _name);
		        params.put("designation",_designation);
		        params.put("content", _content);
		        params.put("branch", _branch);

              return params;
          }

      };

      // Adding request to request queue
      AppController.getInstance().addToRequestQueue(strReq, tag_string_req);
  }

  private void showDialog() {
      if (!pDialog.isShowing())
          pDialog.show();
  }

  private void hideDialog() {
      if (pDialog.isShowing())
          pDialog.dismiss();
  }	
 


  
}
