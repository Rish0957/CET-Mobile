package com.rtupass.application;


import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class myGridAdapterEngg extends ArrayAdapter<Object>{
		
		String[] names;
		int[] images;
		Context con;
		LayoutInflater inflater;


		public myGridAdapterEngg(Context context, int[] image,String[] name) {
			super(context, R.layout.custom_grid_engineering);
			con=context;
			images=image;
			names=name;
			inflater=LayoutInflater.from(context);
			// TODO Auto-generated constructor stub
		}
		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return names.length;
		}
		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return null;
		}
		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return 0;
		}
		
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			if(convertView==null){
				convertView=inflater.inflate(R.layout.custom_grid_engineering, null);
				holder=new ViewHolder();
				holder.iv=(ImageView) convertView.findViewById(R.id.imageView1);
				holder.tv=(TextView) convertView.findViewById(R.id.textView1);
				convertView.setTag(holder);
				Log.d("log", "View Created");
			}
			else{
				holder=(ViewHolder) convertView.getTag();
			}
			
			holder.iv.setImageResource(images[position]);
			holder.tv.setText(names[position]);
			
			return convertView;
		}
		
		class ViewHolder{
			TextView tv;
			ImageView iv;
		}

	}

