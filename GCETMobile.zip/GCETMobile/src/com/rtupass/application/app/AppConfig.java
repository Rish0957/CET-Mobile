package com.rtupass.application.app;

public class AppConfig {

	public static final String URL_Enquiry = "http://gcet.rtupass.com/college/submit_enquiry.php";

	public static String URL_STUDENT_LISTS = "http://gcet.rtupass.com/college/get_classmates_list.php";
	public static final String URL_Report_Spam = "http://gcet.rtupass.com/college/report_spam.php";

	public static final String WebsiteUrl = "http://gcet.rtupass.com";	

	public static  String URL_Teacher_ListS = "http://gcet.rtupass.com/college/teacher_list.php";

	public static  String URL_GENERATE_Notification = "http://gcet.rtupass.com/college/insert_notifications.php";

	public static  String URL_Notification = "http://gcet.rtupass.com/college/get_notifications.php";
	// Server user login url
    public static String URL_LOGIN = "http://gcet.rtupass.com/college/login.php";
 
    // Server user register url
    public static String URL_REGISTER = "http://gcet.rtupass.com/college/register.php";
    
    public static String URL_TEACHER_LOGIN="http://gcet.rtupass.com/college/teacherLogin.php";
    
    public static String URL_GENERATE_POST="http://gcet.rtupass.com/college/insert_feeds.php";
    public static String URL_STUDENT_FEEDS="http://gcet.rtupass.com/college/get_student_feeds.php";
    //
 
//  public static String URL_STUDENT_LISTS = "http://10.0.2.2:90/college/get_classmates_list.php";
//
//	public static  String URL_Teacher_ListS = "http://10.0.2.2:90/college/teacher_list.php";
//	public static final String URL_Enquiry = "http://10.0.2.2:90/college/submit_enquiry.php";
//
//	public static final String URL_Report_Spam = "http://10.0.2.2:90/college/report_spam.php";    
//
//	public static  String URL_GENERATE_Notification = "http://10.0.2.2:90/college/insert_notifications.php";
//
//	public static  String URL_Notification = "http://10.0.2.2:90/college/get_notifications.php";
//	// Server user login url
//    public static String URL_LOGIN = "http://10.0.2.2:90/college/login.php";
// 
//    // Server user register url
//    public static String URL_REGISTER = "http://10.0.2.2:90/college/register.php";
//    
//    public static String URL_TEACHER_LOGIN="http://10.0.2.2:90/college/teacherLogin.php";
//    
//    public static String URL_GENERATE_POST="http://10.0.2.2:90/college/insert_feeds.php";
//    public static String URL_STUDENT_FEEDS="http://10.0.2.2:90/college/get_student_feeds.php";
//    
  

}
