package com.rtupass.application;


import com.rtupass.application.helper.SessionManager;

import android.app.ActionBar;
import android.app.FragmentTransaction;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;

public class DashBoardActivity extends FragmentActivity {
	 static ViewPager Tab;
    DashBoardPagerAdapter DashBoardTabAdapter;
    DashBoardPAgerAdapterTeacher DashBoardTabAdapterTeacher;
	ActionBar actionBar;
	SessionManager session;
//	FloatingActionButton fab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        
       DashBoardTabAdapter = new DashBoardPagerAdapter(getSupportFragmentManager());
       DashBoardTabAdapterTeacher=new DashBoardPAgerAdapterTeacher(getSupportFragmentManager());
        session=new SessionManager(DashBoardActivity.this);
        Tab = (ViewPager)findViewById(R.id.pager);
        
        Tab.setOnPageChangeListener(
                new ViewPager.SimpleOnPageChangeListener() {
                    @Override
                    public void onPageSelected(int position) {
                       
                    	actionBar = getActionBar();
                    	actionBar.setSelectedNavigationItem(position);  
                    	
                    }
                });
        Tab.setBackgroundColor(Color.WHITE);
        
      //  LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        actionBar = getActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#000000")));
        actionBar.setIcon(new ColorDrawable(getResources().getColor(android.R.color.transparent)));
        
        
        //Enable Tabs on Action Bar
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
        
        //if student is logged in then following tabs will be shown
        
        if(!(session.isLoggedIn() && session.isTeacherLoggedIn())){
        	Tab.setAdapter(DashBoardTabAdapter);
        	actionBar.setTitle("Student DashBoard");
        	//Add New Tabs
			//final View tabBackgroung=new CustomView(this);
			//tabBackgroung.setBackgroundColor(Color.parseColor("#fe9900"));
			ActionBar.Tab tab=actionBar.newTab().setText("Profile").setTabListener(new tabListener(this, Profile.class.getName()));
			// View tabView1 = inflater.inflate(R.layout.notes_frag, null);
		       
		        actionBar.addTab(tab);
		    tab=actionBar.newTab().setText("Share").setTabListener(new tabListener(this, GeneratePost.class.getName()));
		   // View tabView2 = inflater.inflate(R.layout.exam_frag, null);
		   // tabView1.setBackgroundColor(Color.parseColor("#fe9900"));
	        actionBar.addTab(tab);
		    tab=actionBar.newTab().setText("Feeds").setTabListener(new tabListener(this, StudentPost.class.getName()));
		//    View tabView3 = inflater.inflate(R.layout.lab_frag, null);
		 //   tabView1.setBackgroundColor(Color.parseColor("#fe9900"));
	        actionBar.addTab(tab);
	        tab=actionBar.newTab().setText("Friends").setTabListener(new tabListener(this, Friends.class.getName()));
	        actionBar.addTab(tab);
        }
        // other wise teacher is logged in and following tabs will be shown for teacher
        else{
        	Tab.setAdapter(DashBoardTabAdapterTeacher);
        	actionBar.setTitle("Teacher DashBoard");
        	
			ActionBar.Tab tab=actionBar.newTab().setText("Profile").setTabListener(new tabListener(this, TeacherProfile.class.getName()));
		    actionBar.addTab(tab);
		    
		    tab=actionBar.newTab().setText("Share").setTabListener(new tabListener(this, GeneratePost.class.getName()));
		    actionBar.addTab(tab);
		
        	
        }

			
	        
//	        fab= new FloatingActionButton.Builder(this)
//			        .withDrawable(getResources().getDrawable(R.drawable.circular_back))
//					.withButtonColor(Color.parseColor("#000000"))
//			        .withGravity(Gravity.BOTTOM | Gravity.RIGHT)
//			        .withMargins(0, 0, 16, 16).create();
//	        fab.setOnClickListener(new View.OnClickListener() {
//				
//				@Override
//				public void onClick(View v) {
//				AlertDialogManager alert=new AlertDialogManager();
//				alert.showAlertDialog(DashBoardActivity.this," Simple Dialog Box", "Some content will soon be displayed here",null);
//				
//				}
//			});
			

    }
    public static class tabListener extends Fragment implements
    ActionBar.TabListener {

		public tabListener(DashBoardActivity mainActivity, String name) {
		    // this(mainActivity,name);
		}
		

		public void onTabSelected(android.app.ActionBar.Tab tab,
		        FragmentTransaction ft) {
		    Tab.setCurrentItem(tab.getPosition());
		}
		
		@Override
		public void onTabUnselected(android.app.ActionBar.Tab tab,
		        FragmentTransaction ft) {
		
		}
		
		@Override
		public void onTabReselected(android.app.ActionBar.Tab tab,
		        FragmentTransaction ft) {
		
		}
		
	}

   
    
}
