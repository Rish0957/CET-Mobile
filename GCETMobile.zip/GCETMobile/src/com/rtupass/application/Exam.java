package com.rtupass.application;

import java.util.ArrayList;

import com.rtupass.application.helper.SessionManager;

import android.app.Activity;
import android.app.Dialog;
import android.app.ActionBar.LayoutParams;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

public class Exam extends Fragment {
	ListView list;
	SQLiteDatabase database;
	TextView heading;
	public ArrayList<String> sub_name,url_exam;
	private String DB_NAME="college.db";
	String sem,branch;
	ArrayAdapter<String> listAdapter;
	ViewDialogExam alert;
	@Override
	    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
	 
	        View exam = inflater.inflate(R.layout.exam_frag, container, false);
	        list=(ListView)exam.findViewById(R.id.listView1);
	        sem=new SessionManager(getActivity()).returnSem();
	        branch=new SessionManager(getActivity()).returnBranch();
	        
	        heading=(TextView)exam.findViewById(R.id.textView1);
	        heading.setText(sem+" Exam Papers");
	        
	        alert=new ViewDialogExam();
	        
	        database=getActivity().openOrCreateDatabase(DB_NAME, Context.MODE_PRIVATE,null);
	        try {
				sub_name=new ArrayList<String>();
				url_exam=new ArrayList<String>();
				
			String query= "select subject_name,url_exam from notes n INNER JOIN semester s ON n.sem_id=s.sem_id "
					+ "INNER JOIN department d ON d.department_id=s.dept_id ";
			query+="where department_name='"+branch+"' and sem_name='"+sem+"' order by n.id asc";
				Cursor c=database.rawQuery(query, null);
				c.moveToFirst();
				if(!c.isAfterLast()) {
					do {
						String name = c.getString(0);
						String url= c.getString(1);
						sub_name.add(name);
						url_exam.add(url);
					} while (c.moveToNext());
				}
				c.close();
				listAdapter=new ArrayAdapter<>(getActivity(),android.R.layout.simple_list_item_1, sub_name);
				list.setAdapter(listAdapter);
				list.setOnItemClickListener(new OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
						// TODO Auto-generated method stub
						alert.showDialogue(getActivity(), sub_name.get(position), url_exam.get(position));
					}
				});

				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	       database.close();
	        
	        return exam;
  }
	public class ViewDialogExam{
		public void showDialogue(Activity activity,final String string,final  String string2) {
			// TODO Auto-generated method stub
			 final Dialog dialog = new Dialog(activity);
		        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		        dialog.setCancelable(true);
		        dialog.setContentView(R.layout.lab_description_dialogue);
		        
		        
			TextView heading_name=(TextView)dialog.findViewById(R.id.lab_name);
			LinearLayout linear=(LinearLayout) dialog.findViewById(R.id.linearmarks);
			Button ok=(Button)dialog.findViewById(R.id.button1);
			final TextView content=(TextView)dialog.findViewById(R.id.textView4);
			
			linear.setVisibility(View.GONE);
			content.setText("Click the below button to start downloading a zip file of previous year exam papers of "+string+" .");
			
			heading_name.setText(string);
			ok.setText("Download");
			ok.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(string2));
					startActivity(browserIntent);
				}
			});
			
		
		
			dialog.show();
			Window window = dialog.getWindow();
			window.setLayout(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
		
			
		}
	}


}
