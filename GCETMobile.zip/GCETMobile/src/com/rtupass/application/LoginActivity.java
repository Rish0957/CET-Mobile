package com.rtupass.application;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

import com.android.volley.Request.Method;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.rtupass.application.app.AppConfig;
import com.rtupass.application.app.AppController;
import com.rtupass.application.helper.SQLiteHandler;
import com.rtupass.application.helper.SessionManager;

import android.animation.ObjectAnimator;
import android.app.ActionBar;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.OvershootInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class LoginActivity extends Activity {
	    private Button btnLogin;
	    private Button btnLinkToRegister;
	    private EditText inputRoll_no;
	    private EditText inputPassword;
	    private ProgressDialog pDialog;
	    private SessionManager session;
	    private SQLiteHandler db;
	    String roll_no,password;
	    StringOperations obj;
	    ImageView logo;
	    JSONParser jParser=new JSONParser();
	    private void flipIt(final View viewToFlip) {
			ObjectAnimator flip = ObjectAnimator.ofFloat(viewToFlip, "rotationY", 0f, 360f);
			flip.setDuration(3000);
			flip.setInterpolator(new OvershootInterpolator());
			flip.start();

		}
	    @Override
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.activity_login);
	        
	        obj=new StringOperations();
	        ActionBar actionBar=getActionBar();
	        actionBar.hide();
	        logo=(ImageView)findViewById(R.id.logo);
	        inputRoll_no = (EditText) findViewById(R.id.roll_no);
	        inputPassword = (EditText) findViewById(R.id.password);
	        btnLogin = (Button) findViewById(R.id.btnLogin);
	        btnLinkToRegister = (Button) findViewById(R.id.btnLinkToRegisterScreen);
	 
	        logo.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					flipIt(logo);
				}
			});
	        
	        // Progress dialog
	        pDialog = new ProgressDialog(this);
	        pDialog.setCancelable(false);
	 
	        // SQLite database handler
	        db = new SQLiteHandler(getApplicationContext());
	 
	        // Session manager
	        session = new SessionManager(getApplicationContext());
	 
	        // Check if user is already logged in or not
	        if (session.isLoggedIn()) {
	            // User is already logged in. Take him to main activity
	            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
	            startActivity(intent);
	            finish();
	        }
	 
	        // Login button Click Event
	        btnLogin.setOnClickListener(new View.OnClickListener() {
	 
	            public void onClick(View view) {
	                roll_no = inputRoll_no.getText().toString().trim();
	                password = inputPassword.getText().toString().trim();
	 
	                // Check for empty data in the form
	                if (!roll_no.isEmpty() && !password.isEmpty()) {
	                   if(obj.isValidRollno(roll_no)){
	                	   checkLogin(roll_no, password);
	                   }
	                   else{
	                	   Toast.makeText(getApplicationContext(),"Invalid Roll Number!", Toast.LENGTH_LONG).show();
	                   }
	                } else {
	                    // Prompt user to enter credentials
	                    Toast.makeText(getApplicationContext(),"Please enter the credentials!", Toast.LENGTH_LONG).show();
	                }
	            }
	 
	        });
	 
	        // Link to Register Screen
	        btnLinkToRegister.setOnClickListener(new View.OnClickListener() {
	 
	            public void onClick(View view) {
	                Intent i = new Intent(getApplicationContext(),RegisterActivity.class);
	                startActivity(i);
	                finish();
	            }
	        });
	 
	    }

	    /**
	     * function to verify login details in mysql db
	     * */
	    private void checkLogin(final String roll_no, final String password) {
	        // Tag used to cancel the request
	        String tag_string_req = "req_login";
	 
	        pDialog.setMessage("Logging in ...");
	        showDialog();
	 
	        StringRequest strReq = new StringRequest(Method.POST,AppConfig.URL_LOGIN, new Response.Listener<String>() {
	 
	            @Override
	            public void onResponse(String response) {
	               // Log.d(TAG, "Login Response: " + response.toString());
	                hideDialog();
	 
	                try {
	                    JSONObject json = new JSONObject(response);
	                   boolean error = json.getBoolean("error");
						if (!error) {
							// User successfully stored in MySQL
							// Now store the user in sqlite
							String uid = json.getString("uid");
				
							JSONObject user = json.getJSONObject("user");
							String name = user.getString("name");
							String email = user.getString("email");
							String roll_no=user.getString("roll_no");
							String phone=user.getString("phone");
							String branch=user.getString("branch");
							String photo_url = user.getString("student_photo");
							String created_at=user.getString("created_at");
							//setting shared prefrences
							 session.clearSharedPreferences();
							 session.setLogin(true,name,email,roll_no,uid,branch);
							// Inserting row in users table
							db.addUser(uid,name,roll_no,email,phone,photo_url,branch,created_at);
				
							Toast.makeText(getApplicationContext(), " Welcome back "+name, Toast.LENGTH_LONG).show();
				
							// Launch Main activity
							Intent intent = new Intent(LoginActivity.this,MainActivity.class);
							startActivity(intent);
							finish();
						} else {
				
							// Error occurred in registration. Get the error
							// message
							String errorMsg = json.getString("error_msg");
							Toast.makeText(getApplicationContext(),errorMsg, Toast.LENGTH_LONG).show();
						}
	                } catch (JSONException e) {
	                    // JSON error
	                    //e.printStackTrace();
	                    Toast.makeText(getApplicationContext(),"Something went wrong!!", Toast.LENGTH_LONG).show();
	                }
	 
	            }
	        }, new Response.ErrorListener() {
	 
	            @Override
	            public void onErrorResponse(VolleyError error) {
	                //Log.e(TAG, "Login Error: " + error.getMessage());
	                //Toast.makeText(getApplicationContext(),error.getMessage(), Toast.LENGTH_LONG).show();
					Toast.makeText(getApplicationContext(),"Uncaught Error!! ,check Internet settings.", Toast.LENGTH_LONG).show();
	                hideDialog();
	            }
	        }) {
	 
	            @Override
	            protected Map<String, String> getParams() {
	                // Posting parameters to login url
	                Map<String, String> params = new HashMap<String, String>();
	                params.put("roll_no", roll_no);
	                params.put("password", password);
	 
	                return params;
	            }
	 
	        };
	 
	        // Adding request to request queue
	        AppController.getInstance().addToRequestQueue(strReq, tag_string_req);
	    }
	 
	    private void showDialog() {
	        if (!pDialog.isShowing())
	            pDialog.show();
	    }
	 
	    private void hideDialog() {
	        if (pDialog.isShowing())
	            pDialog.dismiss();
	    }	

}
