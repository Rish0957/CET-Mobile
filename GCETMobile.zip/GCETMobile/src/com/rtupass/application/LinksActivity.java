package com.rtupass.application;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

public class LinksActivity extends Activity {
	 SQLiteDatabase database;
     private String DB_NAME="college.db";
     ArrayList<String> title,url,trimmed_url;
     ListView list;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_links);
		
		list=(ListView)findViewById(R.id.listView1);
		ExternalDbOpenHelper dbOpenHelper = new ExternalDbOpenHelper(this, DB_NAME);
        database = dbOpenHelper.openDataBase();
        dbOpenHelper.close();
		getActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#000000")));
        getActionBar().setIcon(new ColorDrawable(getResources().getColor(android.R.color.transparent)));
        getActionBar().setTitle("Useful Links");
		 
        database=openOrCreateDatabase(DB_NAME, Context.MODE_PRIVATE, null);
        try {
			title=new ArrayList<String>();
			url=new ArrayList<String>();
			trimmed_url=new ArrayList<String>();
		String query= "select title,link_url from links asc"; 
			Cursor c=database.rawQuery(query, null);
			c.moveToFirst();
			if(!c.isAfterLast()) {
				do {
					String link_title=c.getString(0);
					String link_url=c.getString(1);
					
					trimmed_url.add(link_url.substring(7));
					title.add(link_title);
					url.add(link_url);
				} while (c.moveToNext());
			}
			c.close();
			list.setAdapter(new LinkListAdapter(getApplicationContext(), title, trimmed_url));
			list.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1, int position, long arg3) {
					// TODO Auto-generated method stub
					Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url.get(position)));
					startActivity(browserIntent);
				}
			});
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       database.close();
	}

	
}
