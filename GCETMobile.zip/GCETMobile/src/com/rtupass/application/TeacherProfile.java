package com.rtupass.application;

import java.util.HashMap;

import com.rtupass.application.helper.SQLiteHandler;
import com.rtupass.application.helper.SessionManager;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class TeacherProfile extends Fragment {

ImageView profilePicture;
TextView name,branch,designation,qualification,email,phone;
Button logoutBtn;
SQLiteHandler databaseHandler;
SessionManager session;
PrefManager prefmanager;
  @Override
   public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

    View profile = inflater.inflate(R.layout.frag_teacher_profile, container, false);
    
    
    
    databaseHandler=new SQLiteHandler(getActivity());
    session= new SessionManager(getActivity());
    // for deleting preference of isFirstTimeLaunch()
    prefmanager= new PrefManager(getActivity());
    
    if (!session.isTeacherLoggedIn() ) {
            // If Teacher is not logged in. Take him to login  activity
            Intent intent = new Intent(getActivity(), MainActivity.class);
            startActivity(intent);
            Toast.makeText(getActivity(), "Something went wrong..please login again.",Toast.LENGTH_SHORT).show();
            
        }else{
    
     name=(TextView)profile.findViewById(R.id.textView1);
    designation=(TextView)profile.findViewById(R.id.designation);
    branch=(TextView)profile.findViewById(R.id.branch);
    qualification=(TextView)profile.findViewById(R.id.qualification);
    email=(TextView)profile.findViewById(R.id.email);
    phone=(TextView)profile.findViewById(R.id.mobile);
    
    //getting value from database
    HashMap<String, String> teacher= new HashMap<>();
    teacher=databaseHandler.getTeacherDetails();
    try {
      name.setText(teacher.get("teacher_name"));
      designation.setText(teacher.get("designation"));
      branch.setText(teacher.get("department"));
      phone.setText(teacher.get("phone"));
      email.setText(teacher.get("email"));
      qualification.setText(teacher.get("education"));
    } catch (Exception e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    logoutBtn=(Button)profile.findViewById(R.id.logout);
    logoutBtn.setOnClickListener(new OnClickListener() {
      
      @Override
      public void onClick(View v) {
        // TODO Auto-generated method stub
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage("Are you sure you want to logout?");
        builder.setPositiveButton("Yes",new DialogInterface.OnClickListener() {
          
          @Override
          public void onClick(DialogInterface dialog, int which) {
            try {
              databaseHandler.deleteUsers();
              session.clearSharedPreferences();
              prefmanager.clearPrefrences();
              
              
              startActivity(new Intent(getActivity(),MainActivity.class));
              
            } catch (Exception e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
            }
            
          }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
          
          @Override
          public void onClick(DialogInterface dialog, int which) {
            // TODO Auto-generated method stub
            dialog.cancel();
            
          }
        });
        AlertDialog alert=builder.create();
        alert.show();
        
      }
    });
  }
  return profile;
  }
}
