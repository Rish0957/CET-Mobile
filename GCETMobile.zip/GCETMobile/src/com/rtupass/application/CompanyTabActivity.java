package com.rtupass.application;


import com.rtupass.application.helper.SessionManager;

import android.app.ActionBar;
import android.app.FragmentTransaction;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;

public class CompanyTabActivity extends FragmentActivity {
	 static ViewPager Tab;
    CompanyPagerAdapter companyPagerAdapter;
	ActionBar actionBar;
	SessionManager session;
//	FloatingActionButton fab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        
       companyPagerAdapter = new CompanyPagerAdapter(getSupportFragmentManager());
        session=new SessionManager(CompanyTabActivity.this);
        Tab = (ViewPager)findViewById(R.id.pager);
        
        Tab.setOnPageChangeListener(
                new ViewPager.SimpleOnPageChangeListener() {
                    @Override
                    public void onPageSelected(int position) {
                       
                    	actionBar = getActionBar();
                    	actionBar.setSelectedNavigationItem(position);  
                    	
                    }
                });
        
        actionBar = getActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#000000")));
        actionBar.setIcon(new ColorDrawable(getResources().getColor(android.R.color.transparent)));
        
        
        //Enable Tabs on Action Bar
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
        
        
        
        	Tab.setAdapter(companyPagerAdapter);
        	actionBar.setTitle(session.getCompany());
        	
			ActionBar.Tab tab=actionBar.newTab().setText("Test Pattern").setTabListener(new tabListener(this, TestPattern.class.getName()));
		    actionBar.addTab(tab);

		    tab=actionBar.newTab().setText("Eligibilty").setTabListener(new tabListener(this, Eligibility.class.getName()));
		    actionBar.addTab(tab);
		    
		    tab=actionBar.newTab().setText("Useful Links").setTabListener(new tabListener(this, UsefulLinks.class.getName()));
		    actionBar.addTab(tab);
		
        	
      

			
//	        
//	        fab= new FloatingActionButton.Builder(this)
//			        .withDrawable(getResources().getDrawable(R.drawable.circular_back))
//					.withButtonColor(Color.parseColor("#000000"))
//			        .withGravity(Gravity.BOTTOM | Gravity.RIGHT)
//			        .withMargins(0, 0, 16, 16).create();
//	        fab.setOnClickListener(new View.OnClickListener() {
//				
//				@Override
//				public void onClick(View v) {
//				AlertDialogManager alert=new AlertDialogManager();
//				alert.showAlertDialog(CompanyTabActivity.this," Simple Dialog Box", "Some content will soon be displayed here",null);
//				
//				}
//			});
			

    }
    public static class tabListener extends Fragment implements
    ActionBar.TabListener {

		public tabListener(CompanyTabActivity mainActivity, String name) {
		}
		

		public void onTabSelected(android.app.ActionBar.Tab tab,
		        FragmentTransaction ft) {
		    Tab.setCurrentItem(tab.getPosition());
		}
		
		@Override
		public void onTabUnselected(android.app.ActionBar.Tab tab,
		        FragmentTransaction ft) {
		
		}
		
		@Override
		public void onTabReselected(android.app.ActionBar.Tab tab,
		        FragmentTransaction ft) {
		
		}
		
	}

     


    
}
