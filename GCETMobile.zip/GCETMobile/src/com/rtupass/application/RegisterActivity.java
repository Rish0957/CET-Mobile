package com.rtupass.application;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

import com.android.volley.Request.Method;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.rtupass.application.app.AppConfig;
import com.rtupass.application.app.AppController;
import com.rtupass.application.helper.SQLiteHandler;
import com.rtupass.application.helper.SessionManager;

import android.app.ActionBar;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends Activity {

	private Button btnRegister;
	private Button btnLinkToLogin;
	private EditText inputFullName;
	private EditText inputEmail;
	private EditText inputPassword;
	private EditText roll_No;
	private EditText phone_No;
	private ProgressDialog pDialog;
	private SessionManager session;
	private SQLiteHandler db;
	StringOperations  obj;
	String name,email,password,roll_no,phone,branch="",device_id; 
	String error_validations;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_register);

		ActionBar actionBar=getActionBar();
		actionBar.hide();

		inputFullName = (EditText) findViewById(R.id.name);
		inputEmail = (EditText) findViewById(R.id.email);
		inputPassword = (EditText) findViewById(R.id.password);
		roll_No = (EditText) findViewById(R.id.roll_no);
		phone_No = (EditText) findViewById(R.id.phone);
		btnRegister = (Button) findViewById(R.id.btnRegister);
		btnLinkToLogin = (Button) findViewById(R.id.btnLinkToLoginScreen);




		// Progress dialog
		pDialog = new ProgressDialog(this);
		pDialog.setCancelable(false);

		// Session manager
		session = new SessionManager(getApplicationContext());

		// SQLite database handler
		db = new SQLiteHandler(getApplicationContext());

		// Check if user is already logged in or not
		if (session.isLoggedIn()) {
			// User is already logged in. Take him to main activity
			Intent intent = new Intent(RegisterActivity.this,MainActivity.class);
			startActivity(intent);
			finish();
		}

		// Register Button Click event
		btnRegister.setOnClickListener(new View.OnClickListener() {
			public void onClick(View view) {
				 obj=new StringOperations();
				 name = inputFullName.getText().toString().trim();
			 	 email = inputEmail.getText().toString().trim();
				 password = inputPassword.getText().toString().trim();
				 roll_no = roll_No.getText().toString().trim();
				 phone = phone_No.getText().toString().trim();
				 branch="";
				 try {
					device_id=getIMEI(getApplicationContext());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					Toast.makeText(getApplicationContext(), "Error in retrieving devide id.", Toast.LENGTH_SHORT);
				}
				if(!roll_no.isEmpty() ){

					if(obj.isValidRollno(roll_no) ){
						branch=obj.getBranch(roll_no);
					}
				}

				if (!name.isEmpty() && !email.isEmpty() && !password.isEmpty() && !phone.isEmpty() && !branch.isEmpty() && !device_id.isEmpty()) {
					if(validation(name,email,phone,password)){
						registerUser(name,email,password,roll_no,phone,branch,device_id); 
					}
					else{
						Toast.makeText(getApplicationContext(), error_validations, Toast.LENGTH_LONG).show();
					}
				} else {
					Toast.makeText(getApplicationContext(),"Either missing details or invalid Roll no. !!", Toast.LENGTH_LONG).show();
				}
			}
		});

		// Link to Login Screen
		btnLinkToLogin.setOnClickListener(new View.OnClickListener() {

			public void onClick(View view) {
				Intent i = new Intent(getApplicationContext(),LoginActivity.class);
				startActivity(i);
				finish();
			}
		});

	}
	private String getIMEI(Context context){

	    TelephonyManager mngr = (TelephonyManager) context.getSystemService(context.TELEPHONY_SERVICE); 
	    String imei = mngr.getDeviceId().toString();
	    return imei;

	}
	private void registerUser(final String name, final String email,final String password,final String roll_no,final String phone,final String branch,final String device_id) {
		// Tag used to cancel the request
		Log.d("error",branch);
		String tag_string_req = "req_register";

		pDialog.setMessage("Registering ...");
		showDialog();

		StringRequest strReq = new StringRequest(Method.POST,
				AppConfig.URL_REGISTER, new Response.Listener<String>() {

			@Override
			public void onResponse(String response) {
				//Log.d(TAG, "Register Response: " + response.toString());
				hideDialog();

				try {
					JSONObject json = new JSONObject(response);
					boolean error = json.getBoolean("error");
						if (!error) {
					// User successfully stored in MySQL
					// Now store the user in sqlite
					String uid = json.getString("uid");

					JSONObject user = json.getJSONObject("user");
					String name = user.getString("name");
					String email = user.getString("email");
					String roll_no=user.getString("roll_no");
					String phone=user.getString("phone");
					String branch=user.getString("branch");
					String photo_url = user.getString("student_photo");
					String created_at=user.getString("created_at");
					//setting shared preferences
					 session.clearSharedPreferences();
					 session.setLogin(true,name,email,roll_no,uid,branch);
					// Inserting row in users table
					db.addUser(uid,name,roll_no,email,phone,photo_url,branch,created_at);

					Toast.makeText(getApplicationContext(), "Welcome "+name+", to GCET Mobile App!", Toast.LENGTH_LONG).show();

					// Launch Main activity
					Intent intent = new Intent(RegisterActivity.this,MainActivity.class);
					startActivity(intent);
					finish();
				} else {

					// Error occurred in registration. Get the error
					// message
					String errorMsg = json.getString("error_msg");
					Toast.makeText(getApplicationContext(),errorMsg, Toast.LENGTH_LONG).show();
				}
				} catch (JSONException e) {
					e.printStackTrace();
					Toast.makeText(getApplicationContext(),"Unknown Error occured! We're sorry,please report this.", Toast.LENGTH_LONG).show();
				}

			}
		}, new Response.ErrorListener() {

			@Override
			public void onErrorResponse(VolleyError error) {
				//Log.e(TAG, "Registration Error: " + error.getMessage());
				Toast.makeText(getApplicationContext(),"Network Error!!", Toast.LENGTH_LONG).show();
				hideDialog();
			}
		}) {

			@Override
			protected Map<String, String> getParams() {
				// Posting params to register url
				Map<String, String> params = new HashMap<String, String>();
				params.put("student_name", name);
				params.put("student_email", email);
				params.put("roll_no",roll_no);
				params.put("student_phone", phone);
				params.put("branch", branch);
				params.put("password", password);
				params.put("imei", device_id);


				return params;
			}

		};

		// Adding request to request queue
		AppController.getInstance().addToRequestQueue(strReq, tag_string_req);
	}
private boolean validation(String name,String email,String phone,String password){
	boolean no_error=true;
	int aa=Integer.parseInt(phone.substring(0,1));
	String EMAIL_REGEX = "^[\\w-_\\.+]*[\\w-_\\.]\\@gmail.com";
	Log.d("Email", email);
	Log.d("Matches? -->", email.matches(EMAIL_REGEX)+"");
	
	if(!(phone.length()==10)){
		error_validations="Please enter a 10 digit mobile number!";
		no_error=false;
	}
	
	if(phone.length()==10){
		switch (aa) {
		case 9:
			no_error=true;
			break;
		case 8:
			no_error=true;
			break;
		case 7:
			no_error=true;
			break;

		default:
			error_validations="Invalid mobile number.";
			no_error=false;
			break;
		}
	}
	if(name.length()<7){
		error_validations="Enter your full name.";
		no_error=false;
	}
	if(password.length()<4){
		error_validations="Password is too short.";
		no_error=false;
	}
	if(!(email.matches(EMAIL_REGEX))){
		no_error=false;
		error_validations="Please provide your Gmail Id!!";
	}
	if(!obj.isValidRollno(roll_no)){
		no_error=false;
		error_validations="Roll number is not valid";
	}
	return no_error;
}
	private void showDialog() {
		if (!pDialog.isShowing())
			pDialog.show();
	}

	private void hideDialog() {
		if (pDialog.isShowing())
			pDialog.dismiss();
	}
	
}
