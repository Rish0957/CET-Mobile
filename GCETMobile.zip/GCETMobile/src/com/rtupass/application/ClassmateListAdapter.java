package com.rtupass.application;

import java.util.List;

import LruBitmapCache.ClassmateItem;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class ClassmateListAdapter extends BaseAdapter {
	 private Activity activity;
	    private LayoutInflater inflater;
	    private List<ClassmateItem> classmateItems;

	    public ClassmateListAdapter(Activity activity, List<ClassmateItem> classmateItems) {
	        this.activity = activity;
	        this.classmateItems = classmateItems;
	    }
	 
	    @Override
	    public int getCount() {
	        return classmateItems.size();
	    }
	 
	    @Override
	    public Object getItem(int location) {
	        return classmateItems.get(location);
	    }
	 
	    @Override
	    public long getItemId(int position) {
	        return position;
	    }
	 
	    @Override
	    public View getView(int position, View convertView, ViewGroup parent) {
	 
	        if (inflater == null)
	            inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	        if (convertView == null)
	            convertView = inflater.inflate(R.layout.classmate_item, null);
	 
	        TextView name = (TextView) convertView.findViewById(R.id.std_name);
	        TextView timestamp = (TextView) convertView.findViewById(R.id.std_timestamp);
	        TextView roll_no= (TextView) convertView.findViewById(R.id.std_roll_no);
	        ClassmateItem item = classmateItems.get(position);
	 
	        name.setText((position+1)+". "+item.getName());
	        timestamp.setText("Joined on "+item.getTimeStamp());
	        roll_no.setText(item.getRoll_no().toUpperCase());
	        return convertView;
	    }
}
