package com.rtupass.application;

import java.util.ArrayList;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class Emergency extends Activity {
ActionBar ab;
ListView police_station,police_officer,hospital;
TextView polSt,polOff,hosp;
SQLiteDatabase database;
private static final String DB_NAME = "college.db";
ArrayList<String> st_name,st_distance,st_contact,st_address;
ArrayList<String> hos_name,hos_distance,hos_address;
int countA=0,countB=0,countC=0;
ArrayList<String> pol_name,pol_phone,pol_designation;
PoliceStationAdapter st_adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_emergency);
		
		police_station=(ListView)findViewById(R.id.listViewpolice);
		police_officer=(ListView)findViewById(R.id.listViewPoliceOfficers);
		hospital=(ListView)findViewById(R.id.listViewMedical);
		polSt=(TextView)findViewById(R.id.pol_station);
		polOff=(TextView)findViewById(R.id.pol_officer);
		hosp=(TextView)findViewById(R.id.hospital_near);
		
		ab=getActionBar();
		ab.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#000000")));
        ab.setIcon(new ColorDrawable(getResources().getColor(android.R.color.transparent)));
        ab.setTitle("  Emergency");	   
        
    	    police_station.setVisibility(View.GONE);
			police_officer.setVisibility(View.GONE);
			hospital.setVisibility(View.GONE);
      //database
		database=openOrCreateDatabase(DB_NAME, Context.MODE_PRIVATE,null);
        //////////////////////////////////////////////////////////////////////////////////////////////////////////
		//////////////---For Police Stations//////////////////////////////////////////////////////////////////////
		try {
			st_name=new ArrayList<String>();
			st_distance=new ArrayList<String>();
			st_contact=new ArrayList<String>();
			st_address=new ArrayList<String>();
		String query= "select name,distance,contact,address from emergency where type='police' and id<4 " ;
			Cursor c=database.rawQuery(query, null);
			c.moveToFirst();
			if(!c.isAfterLast()) {
				do {
					String name = c.getString(0);
					String distance=c.getString(1);
					String contact=c.getString(2);
					String address=c.getString(3);
					
					st_name.add(name);st_distance.add(distance);st_contact.add(contact);st_address.add(address);
				} while (c.moveToNext());
			}
			c.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//--------For Police Officers--////////////////////////////////////////////////////////////////////////////
		try {
			pol_name=new ArrayList<String>();
			pol_phone=new ArrayList<String>();
			pol_designation=new ArrayList<String>();
		String query= "select name,contact,address from emergency where type='police' and id>3 " ;
			Cursor c=database.rawQuery(query, null);
			c.moveToFirst();
			if(!c.isAfterLast()) {
				do {
					String name = c.getString(0);
					String phone=c.getString(1);
					String designation=c.getString(2);

					pol_name.add(name);pol_phone.add(phone);pol_designation.add(designation);
				} while (c.moveToNext());
			}
			c.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	///////////////////////////////////////////////////////////////////////////////////////////////////////////
	//--------For List of Hospitals--////////////////////////////////////////////////////////////////////////////
		try {
			hos_name=new ArrayList<String>();
			hos_distance=new ArrayList<String>();
			hos_address=new ArrayList<String>();
		String query= "select name,distance,address from emergency where type='medical' " ;
			Cursor c=database.rawQuery(query, null);
			c.moveToFirst();
			if(!c.isAfterLast()) {
				do {
					String name = c.getString(0);
					String distance=c.getString(1);
					String address=c.getString(2);
					
					hos_name.add(name);hos_distance.add(distance);hos_address.add(address);
				} while (c.moveToNext());
			}
			c.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	///////////////////////////////////////////////////////////////////////////////////////////////////////////	
       database.close();
        
       st_adapter=new PoliceStationAdapter(getApplicationContext(), st_name, st_distance, st_contact, st_address);
       police_station.setAdapter(st_adapter);
       
       PoliceOfficerAdapter pol_adapter=new PoliceOfficerAdapter(getApplicationContext(), pol_name, pol_phone, pol_designation);
       police_officer.setAdapter(pol_adapter);
       
       HospitalAdapter hos_adapter=new HospitalAdapter(getApplicationContext(), hos_name, hos_distance, hos_address);
       hospital.setAdapter(hos_adapter);
       
       ListUtils.setDynamicHeight(police_station);
       ListUtils.setDynamicHeight(police_officer);
       ListUtils.setDynamicHeight(hospital);
       
//       polSt=(TextView)findViewById(R.id.pol_station);
//		polOff=(TextView)findViewById(R.id.pol_officer);
//		hosp=(TextView)findViewById(R.id.hospital_near);
       
       polSt.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			countA++;
			if((countA%2)==0){
				police_station.setVisibility(View.GONE);
			}else{
				police_station.setVisibility(View.VISIBLE);
			}
		}
	});
       polOff.setOnClickListener(new OnClickListener() {
   		
   		@Override
   		public void onClick(View v) {
   			// TODO Auto-generated method stub
   			countB++;
   			if((countB%2)==0){
   				police_officer.setVisibility(View.GONE);
   			}else{
   				police_officer.setVisibility(View.VISIBLE);
   			}
   		}
   	});
       hosp.setOnClickListener(new OnClickListener() {
   		
   		@Override
   		public void onClick(View v) {
   			// TODO Auto-generated method stub
   			countC++;
   			if((countC%2)==0){
   				hospital.setVisibility(View.GONE);
   			}else{
   				hospital.setVisibility(View.VISIBLE);
   			}
   		}
   	});
       
        
	}
	
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		//super.onBackPressed();
		//Toast.makeText(getApplicationContext(), "You pressed back.", Toast.LENGTH_SHORT).show();
		startActivity(new Intent(Emergency.this,HelpActivity.class));
		finish();	
	
	}
//-----------------------------------------------------------------------------------------------------------------------------------------
//-------------List Adapter for List of Police Stations
	public class PoliceStationAdapter  extends BaseAdapter {  
	    private Context activity;
	    private LayoutInflater inflater;
	    private ArrayList<String> name,distance, phone, adddress;
//	    ImageLoader imageLoader = AppController.getInstance().getImageLoader();
	 
	    public PoliceStationAdapter(Context activity, ArrayList<String> name,ArrayList<String> distance,ArrayList<String> phone,ArrayList<String> adddress) {
	        this.activity = activity;
	        this.name=name;
	        this.distance=distance;
	        this.adddress=adddress;
	        this.phone=phone;
	    }
	 
	    @Override
	    public int getCount() {
	        return name.size();
	    }
	 
	    @Override
	    public Object getItem(int location) {
	        return name.get(location);
	    }
	 
	    @Override
	    public long getItemId(int position) {
	        return position;
	    }
	 
	    @Override
	    public View getView(int position, View convertView, ViewGroup parent) {
	 
	        if (inflater == null)
	            inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	        if (convertView == null)
	            convertView = inflater.inflate(R.layout.emergency_custom, null);
	 
	        TextView name_ = (TextView) convertView.findViewById(R.id.name);
	        TextView distance_ = (TextView) convertView.findViewById(R.id.distance);
	        TextView phone_ = (TextView) convertView.findViewById(R.id.phone);
	        TextView address_ = (TextView) convertView.findViewById(R.id.address);
	 
	        name_.setText(name.get(position));
	        distance_.setText(distance.get(position));
	        phone_.setText(phone.get(position));
	        address_.setText(adddress.get(position));
	 
	 
	        return convertView;
	    }
	}
//-----------------------------------------------------------------------------------------------------------------------------------------
	public class PoliceOfficerAdapter  extends BaseAdapter {  
	    private Context activity;
	    private LayoutInflater inflater;
	    private ArrayList<String> name, phone, designation;
	 
	    public PoliceOfficerAdapter(Context activity, ArrayList<String> name,ArrayList<String> phone,ArrayList<String> designation) {
	        this.activity = activity;
	        this.name=name;
	        this.phone=phone;
	        this.designation=designation;
	    }
	 
	    @Override
	    public int getCount() {
	        return name.size();
	    }
	 
	    @Override
	    public Object getItem(int location) {
	        return name.get(location);
	    }
	 
	    @Override
	    public long getItemId(int position) {
	        return position;
	    }
	 
	    @Override
	    public View getView(int position, View convertView, ViewGroup parent) {
	 
	        if (inflater == null)
	            inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	        if (convertView == null)
	            convertView = inflater.inflate(R.layout.police_officer, null);
	 
	        TextView name_ = (TextView) convertView.findViewById(R.id.name);
	        TextView phone_ = (TextView) convertView.findViewById(R.id.phone);
	        TextView designation_ = (TextView) convertView.findViewById(R.id.designation);
	 
	        name_.setText(name.get(position));
	        phone_.setText(phone.get(position));
	        designation_.setText(designation.get(position));
	 
	 
	        return convertView;
	    }
	}
//-----------------------------------------------------------------------------------------------------------------------------------------------
	//-------------List Adapter for List of Hospitals
		public class HospitalAdapter  extends BaseAdapter {  
		    private Context activity;
		    private LayoutInflater inflater;
		    private ArrayList<String> name,distance,adddress;
		 
		    public HospitalAdapter(Context activity, ArrayList<String> name,ArrayList<String> distance,ArrayList<String> adddress) {
		        this.activity = activity;
		        this.name=name;
		        this.distance=distance;
		        this.adddress=adddress;
		    }
		 
		    @Override
		    public int getCount() {
		        return name.size();
		    }
		 
		    @Override
		    public Object getItem(int location) {
		        return name.get(location);
		    }
		 
		    @Override
		    public long getItemId(int position) {
		        return position;
		    }
		 
		    @Override
		    public View getView(int position, View convertView, ViewGroup parent) {
		 
		        if (inflater == null)
		            inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		        if (convertView == null)
		            convertView = inflater.inflate(R.layout.emergency_custom, null);
		 
		        TextView name_ = (TextView) convertView.findViewById(R.id.name);
		        TextView distance_ = (TextView) convertView.findViewById(R.id.distance);
		        TextView phone_ = (TextView) convertView.findViewById(R.id.phone);
		        TextView address_ = (TextView) convertView.findViewById(R.id.address);
		 
		        name_.setText(name.get(position));
		        distance_.setText(distance.get(position));
		        phone_.setVisibility(View.GONE);
		        address_.setText(adddress.get(position));
		 
		 
		        return convertView;
		    }
		}
	//-----------------------------------------------------------------------------------------------------------------------------------------
		 public static class ListUtils {
		        public static void setDynamicHeight(ListView mListView) {
		            ListAdapter mListAdapter = mListView.getAdapter();
		            if (mListAdapter == null) {
		                // when adapter is null
		                return;
		            }
		            int height = 0;
		            int desiredWidth = MeasureSpec.makeMeasureSpec(mListView.getWidth(), MeasureSpec.UNSPECIFIED);
		            for (int i = 0; i < mListAdapter.getCount(); i++) {
		                View listItem = mListAdapter.getView(i, null, mListView);
		                listItem.measure(desiredWidth, MeasureSpec.UNSPECIFIED);
		                height += listItem.getMeasuredHeight();
		            }
		            ViewGroup.LayoutParams params = mListView.getLayoutParams();
		            params.height = height + (mListView.getDividerHeight() * (mListAdapter.getCount() - 1));
		            mListView.setLayoutParams(params);
		            mListView.requestLayout();
		        }
		    }
}
