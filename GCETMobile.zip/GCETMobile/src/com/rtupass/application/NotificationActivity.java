package com.rtupass.application;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.android.volley.AuthFailureError;
import com.android.volley.Cache;
import com.android.volley.Request.Method;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.StringRequest;
import com.rtupass.application.app.AppConfig;
import com.rtupass.application.app.AppController;
import com.rtupass.application.helper.SessionManager;

import LruBitmapCache.NotificationItem;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.Toast;

public class NotificationActivity extends Activity  {
    private static final String TAG = NotificationActivity.class.getSimpleName();
    private ListView listView;
    private NotificationListAdapter listAdapter;
    private List<NotificationItem> feedItems;
    private ProgressDialog pDialog;
    SessionManager session;
    AlertDialogManager alert;
    String branch;
    private String URL_Notification = AppConfig.URL_Notification;
 
   @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_notification);

    	pDialog = new ProgressDialog(NotificationActivity.this);
        pDialog.setCancelable(false);

        session=new SessionManager(getApplicationContext());
        
        
	           if(session.isTeacherLoggedIn() && session.isLoggedIn()){
	        	   
	           	branch=session.returnDepartment();
	           	Log.d("teacher logged in ","true");
	           }
	           else if(session.isLoggedIn()){
	        	   Log.d("Student logged in ","true");
	           	branch=session.getBranch();
	           } else{
	        	   Toast.makeText(getApplicationContext(), "Please Login First!!", Toast.LENGTH_SHORT).show();
	        	   startActivity(new Intent(NotificationActivity.this,MainActivity.class));
	        	   finish();
	           }
	           Log.d("Branch", branch);
                 listView = (ListView) findViewById(R.id.list1);                
                
                feedItems = new ArrayList<NotificationItem>();
         
                listAdapter = new NotificationListAdapter(getApplicationContext(), feedItems);
                listView.setAdapter(listAdapter);
               
                
                getActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#000000")));
                getActionBar().setIcon(new ColorDrawable(getResources().getColor(android.R.color.transparent)));
                getActionBar().setTitle("Notifications");
              //   We first check for cached request
                Cache cache = AppController.getInstance().getRequestQueue().getCache();
                Cache.Entry entry = cache.get(URL_Notification);
                if (entry != null) {
                    // fetch the data from cache
                    try {
                        String data = new String(entry.data, "UTF-8");
                        Log.d("skjdnksjdcsdjcds", data);
                        
                            try {
                                parseJsonFeed(data);
                            } catch (Exception e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                            }
                        
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
         
                } else {
                   //  making fresh volley request and getting json
                   freshVolleyRequest1();
                
                }
       
        
            
       
    }
   public void refreshList1(){
//       if (!isInternetPresent) {
//            // Internet Connection is not present
//            alert=new AlertDialogManager();
//            alert.showAlertDialog(getApplicationContext(), "Internet Connection Error","Please connect to working Internet connection", false);
//            // stop executing code and return to mainActivity
//            startActivity(new Intent(getApplicationContext(),MainActivity.class));
//        }
//       else{
    	   Log.d("refreshing", "refreshing inside else block");
	   if(!feedItems.isEmpty()){
			   feedItems.clear();
			   }
			   Log.d("refreshing", "Initiating refresh");
			   freshVolleyRequest1();
//         }
//       }
   }
    
    public void freshVolleyRequest1(){
        
        pDialog.setMessage("Fetching Notifications.Please Wait...");
        showDialog();
         StringRequest jsonReq = new StringRequest( Method.POST,URL_Notification, new Response.Listener<String>(){

                 @Override
                 public void onResponse(String response) {
                     VolleyLog.d(TAG, "Response: " + response.toString());
                     Log.d(TAG, "Response: " + response.toString());
                     if (response != null) {
                         
                         parseJsonFeed(response);
                         hideDialog();
                     }
                 }
             }, new Response.ErrorListener() {

                 @Override
                 public void onErrorResponse(VolleyError error) {
                     VolleyLog.d(TAG, "Error: " + error.getMessage());
                     hideDialog();
                     Toast.makeText(getApplicationContext(), "Please Connect to Internet!!", Toast.LENGTH_LONG).show();
                 }
             }){
        @Override
        protected Map<String, String> getParams() throws AuthFailureError {
             Map<String, String> params = new HashMap<String, String>();
              params.put("branch", branch);
              Log.d("branch", branch);
              return params;
        }
        
     };

     // Adding request to volley request queue
     AppController.getInstance().addToRequestQueue(jsonReq);
    }
    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }
    /**
     * Parsing json reponse and passing the data to feed view list adapter
     * */
    private void parseJsonFeed(String responseString) {
        try {
            JSONObject response=new JSONObject(responseString);
            Log.d("Json",response.toString());
            boolean  error = response.getBoolean("error");
            
           if(!error){
               JSONArray feedArray = response.getJSONArray("feed");
               
               for (int i = 0; i < feedArray.length(); i++) {
                   JSONObject feedObj = (JSONObject) feedArray.get(i);
    
                   NotificationItem item = new NotificationItem();
                   item.setId(feedObj.getInt("post_id"));
                   item.setName(feedObj.getString("posted_by"));                   
                   item.setBranch(feedObj.getString("branch"));
                   item.setDesignation(feedObj.getString("designation"));
                   item.setContent(feedObj.getString("content"));
                   item.setTimeStamp(feedObj.getString("posted_on"));
    
                   feedItems.add(item);
               }
           }
           else {
               // Error in fetching data. Get the error message
               String errorMsg = response.getString("error_msg");
               Toast.makeText(getApplicationContext(),errorMsg, Toast.LENGTH_LONG).show();
           }
 
            // notify data changes to list adapater
            listAdapter.notifyDataSetChanged();
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(),"Uncaught Error Occured! Check Internet.", Toast.LENGTH_LONG).show();
        }
    }
 

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.notification, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if(id==R.id.refreshNotifications){
                refreshList1();
        }
        
        return super.onOptionsItemSelected(item);
    }

    
}
