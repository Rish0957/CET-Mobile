package com.rtupass.application;

import java.util.ArrayList;

import android.app.ActionBar;
import android.app.ActionBar.LayoutParams;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class DivisionEngg extends Activity {
ExpandableHeightGridView grid_branches;
private String DB_NAME="college.db";
ViewDialogEngg alert;
SQLiteDatabase database;
Button info_btn;
ActionBar actionBar;
ArrayList<String> branch_name,branch_description;
String name_branches[]={"CS","Civil","EC","Electrical","Mechanical","Ceramic"};
int images_branches[]={R.drawable.cse,R.drawable.civil,R.drawable.electronics,R.drawable.electrical,R.drawable.mechanical,R.drawable.ceramic};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_division_engg);
		
		//view dialog
		alert=new ViewDialogEngg();

		//action bar
		 	actionBar = getActionBar();
	        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#000000")));
	        actionBar.setIcon(new ColorDrawable(getResources().getColor(android.R.color.transparent)));
	        actionBar.setTitle("  Engineering ");
	        
	        grid_branches=(ExpandableHeightGridView)findViewById(R.id.gridView_branches);
	        info_btn=(Button)findViewById(R.id.button1);
	        
	      //database
			database=openOrCreateDatabase(DB_NAME, Context.MODE_PRIVATE,null);
	        try {
				branch_name=new ArrayList<String>();
				branch_description=new ArrayList<String>();
			String query= "select department_name,dept_description from department ";
				Cursor c=database.rawQuery(query, null);
				c.moveToFirst();
				if(!c.isAfterLast()) {
					do {
						String name = c.getString(0);
						String description=c.getString(1);
						branch_name.add(name);
						branch_description.add(description);
					} while (c.moveToNext());
				}
				c.close();
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	       database.close();
	        
		grid_branches.setAdapter(new myGridAdapterEngg(DivisionEngg.this, images_branches, name_branches));
		grid_branches.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				// TODO Auto-generated method stub
				alert.showDialogue(DivisionEngg.this,branch_name.get(position),branch_description.get(position));
			}
		});
		
		info_btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				showCustomDialog();
				
			}
		});
		
	}
	@Override
		public void onBackPressed() {
			// TODO Auto-generated method stub
			//super.onBackPressed();
			//Toast.makeText(getApplicationContext(), "You pressed back.", Toast.LENGTH_SHORT).show();
			startActivity(new Intent(DivisionEngg.this,DivisionsActivity.class));
			finish();	
		
		}
	public class ViewDialogEngg{
		public void showDialogue(Context activity,final String string,final String string3) {
			// TODO Auto-generated method stub
			 final Dialog dialog = new Dialog(activity);
		        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		        dialog.setCancelable(true);
		        dialog.setContentView(R.layout.lab_description_dialogue);
		        
		        
			TextView heading_name=(TextView)dialog.findViewById(R.id.lab_name);
			LinearLayout linear=(LinearLayout) dialog.findViewById(R.id.linearmarks);
			Button ok=(Button)dialog.findViewById(R.id.button1);
			final TextView content=(TextView)dialog.findViewById(R.id.textView4);
			
			linear.setVisibility(View.GONE);
			heading_name.setText(string);
			content.setText(string3);
			ok.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					dialog.dismiss();
				}
			});
			
			dialog.show();
			Window window = dialog.getWindow();
			window.setLayout(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
		
			
		}
	}
	
	private void showCustomDialog(){
		Context context = getApplicationContext();
        // Create layout inflator object to inflate toast.xml file
        LayoutInflater inflater = getLayoutInflater();
          
        // Call toast.xml file for toast layout 
        View toastRoot = inflater.inflate(R.layout.custom_toast, null);
          
        Toast toast = new Toast(context);
         
        // Set layout to toast 
        toast.setView(toastRoot);
        toast.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL, 0, 0);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.show();
	}

	
}
