package com.rtupass.application;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.android.volley.AuthFailureError;
import com.android.volley.Cache;
import com.android.volley.Request.Method;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.StringRequest;
import com.rtupass.application.app.AppConfig;
import com.rtupass.application.app.AppController;
import com.rtupass.application.helper.SessionManager;

import LruBitmapCache.TeacherDirectoryItem;
import android.app.Activity;
import android.app.ProgressDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class TeachersDirectory extends Activity  {
    private static final String TAG = TeachersDirectory.class.getSimpleName();
    private ListView listView;
    private EditText search;
    private TeacherListAdapter listAdapter;
    private List<TeacherDirectoryItem> feedItems;
    private ProgressDialog pDialog;
    SessionManager session;
    AlertDialogManager alert;
    private String URL_Teacher_List = AppConfig.URL_Teacher_ListS;
 
   @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_teachers_directory);

        pDialog = new ProgressDialog(TeachersDirectory.this);
        pDialog.setCancelable(false);
			
	
			     listView = (ListView) findViewById(R.id.list);   
		       search =(EditText) findViewById(R.id.search);
		        //process dialogue
		       
		        
		        feedItems = new ArrayList<TeacherDirectoryItem>();
		 
		        listAdapter = new TeacherListAdapter(getApplicationContext(), feedItems);
		        listView.setAdapter(listAdapter);
		        search.addTextChangedListener(new TextWatcher() {
					
					@Override
					public void onTextChanged(CharSequence s, int start, int before, int count) {
						// TODO Auto-generated method stub
						TeachersDirectory.this.listAdapter.getFilter().filter(s);
					}
					
					@Override
					public void beforeTextChanged(CharSequence s, int start, int count, int after) {
						// TODO Auto-generated method stub
						
					}
					
					@Override
					public void afterTextChanged(Editable s) {
						// TODO Auto-generated method stub
						
					}
				});
		        
		        getActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#000000")));
		        getActionBar().setIcon(new ColorDrawable(getResources().getColor(android.R.color.transparent)));
		 
		        // We first check for cached request
		        Cache cache = AppController.getInstance().getRequestQueue().getCache();
		        Cache.Entry entry = cache.get(URL_Teacher_List);
		        if (entry != null) {
		            // fetch the data from cache
		            try {
		                String data = new String(entry.data, "UTF-8");
		                Log.d("skjdnksjdcsdjcds", data);
		                
		                    try {
								parseJsonFeed(data);
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
		                
		            } catch (UnsupportedEncodingException e) {
		                e.printStackTrace();
		            }
		 
		        } else {
		            // making fresh volley request and getting json
		           freshVolleyRequest();
		        }
    }
   
   public void refreshList(){

		   Log.d("refreshing", "refreshing inside else block");
		   if(!feedItems.isEmpty()){
			   feedItems.clear();
			   Log.d("refreshing", "Initiating refresh");
			   freshVolleyRequest();
		   	}
   }
    
    public void freshVolleyRequest(){
    	
        pDialog.setMessage("Please Wait...");
        showDialog();
    	 StringRequest jsonReq = new StringRequest( Method.POST,URL_Teacher_List, new Response.Listener<String>(){

                 @Override
                 public void onResponse(String response) {
                     VolleyLog.d(TAG, "Response: " + response.toString());
                     if (response != null) {
                    	 
                         parseJsonFeed(response);
                         hideDialog();
                     }
                 }
             }, new Response.ErrorListener() {

                 @Override
                 public void onErrorResponse(VolleyError error) {
                     VolleyLog.d(TAG, "Error: " + error.getMessage());
                     Toast.makeText(getApplicationContext(), "Please connect to Internet!!", Toast.LENGTH_LONG).show();
                     hideDialog();
                 }
             }){
     	@Override
     	protected Map<String, String> getParams() throws AuthFailureError {
     		 Map<String, String> params = new HashMap<String, String>();
              params.put("roll_no", "13ectcs087");
              return params;
     	}
     	
     };

     // Adding request to volley request queue
     AppController.getInstance().addToRequestQueue(jsonReq);
    }
    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }
    /**
     * Parsing json reponse and passing the data to feed view list adapter
     * */
    private void parseJsonFeed(String responseString) {
        try {
        	JSONObject response=new JSONObject(responseString);
        	Log.d("Json",response.toString());
        	boolean  error = response.getBoolean("error");
			
           if(!error){
        	   JSONArray feedArray = response.getJSONArray("feed");
        	   
               for (int i = 0; i < feedArray.length(); i++) {
                   JSONObject feedObj = (JSONObject) feedArray.get(i);
    
                   TeacherDirectoryItem item = new TeacherDirectoryItem();
                   item.setId(feedObj.getInt("teacher_id"));
                   item.setName(feedObj.getString("name"));
    
                   // Image might be null sometimes
                  // String image = feedObj.isNull("image") ? null : feedObj.getString("image"); I'm not using Images right now (only profile picture)
                  // item.setImge(image);
                   
                   item.setBranch(feedObj.getString("branch"));
                 //item.setProfilePic(feedObj.isNull("profile_pic_url") ? null : feedObj.getString("image"));
                   item.setDesignation(feedObj.getString("designation"));
                   item.setQualification(feedObj.getString("qualification"));
                   item.setEmail(feedObj.isNull("email")?null:feedObj.getString("email"));
                   item.setPhone(feedObj.isNull("phone")?null:feedObj.getString("phone"));
    
                   feedItems.add(item);
               }
           }
           else {
               // Error in login. Get the error message
               String errorMsg = response.getString("error_msg");
               Toast.makeText(getApplicationContext(),errorMsg, Toast.LENGTH_LONG).show();
           }
 
            // notify data changes to list adapater
            listAdapter.notifyDataSetChanged();
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(),"Uncaught Error Occured! Check Internet.", Toast.LENGTH_LONG).show();
        }
    }
 

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.teachers_directory, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		
		switch (id) {
		
		case R.id.refresh:
			{
				refreshList();
				break;
			}

		
		}
		return super.onOptionsItemSelected(item);
	}

	
}
