package com.rtupass.application;

import java.util.HashMap;

import com.rtupass.application.helper.SQLiteHandler;
import com.rtupass.application.helper.SessionManager;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Profile extends Fragment {

ImageView profilePicture;
TextView st_name,st_rollno,st_branch,st_phone,st_email;
Button logoutBtn;
SQLiteHandler databaseHandler;
SessionManager session;
PrefManager prefmanager;
  @Override
   public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

    View profile = inflater.inflate(R.layout.frag_profile, container, false);
    
    
    
    databaseHandler=new SQLiteHandler(getActivity());
    session= new SessionManager(getActivity());
    // for deleting preference of isFirstTimeLaunch()
    prefmanager= new PrefManager(getActivity());
    
    if (!session.isLoggedIn() ) {
            // User is not logged in. Take him to login  activity
            Intent intent = new Intent(getActivity(), LoginActivity.class);
            startActivity(intent);
            getActivity().finish();
            Toast.makeText(getActivity(), "Please Login First",Toast.LENGTH_SHORT).show();
            
        }else{
    
    st_name=(TextView)profile.findViewById(R.id.textView1);
    st_rollno=(TextView)profile.findViewById(R.id.roll_no);
    st_branch=(TextView)profile.findViewById(R.id.department);
    st_phone=(TextView)profile.findViewById(R.id.mobile);
    st_email=(TextView)profile.findViewById(R.id.email);
    
    //getting value from database
    HashMap<String, String> student= new HashMap<>();
    student=databaseHandler.getUserDetails();
    try {
      st_name.setText(student.get("student_name"));
      st_rollno.setText(student.get("roll_no"));
      st_branch.setText(student.get("branch"));
      st_phone.setText(student.get("student_phone"));
      st_email.setText(student.get("student_email"));
    } catch (Exception e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    logoutBtn=(Button)profile.findViewById(R.id.logout);
    logoutBtn.setOnClickListener(new OnClickListener() {
      
      @Override
      public void onClick(View v) {
        // TODO Auto-generated method stub
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage("Are you sure you want to logout?");
        builder.setPositiveButton("Yes",new DialogInterface.OnClickListener() {
          
          @Override
          public void onClick(DialogInterface dialog, int which) {
            try {
              databaseHandler.deleteUsers();
              session.clearSharedPreferences();
              prefmanager.clearPrefrences();
              
              
              startActivity(new Intent(getActivity(),MainActivity.class));
              getActivity().finish();
              
            } catch (Exception e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
            }
            
          }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
          
          @Override
          public void onClick(DialogInterface dialog, int which) {
            // TODO Auto-generated method stub
            dialog.cancel();
            
          }
        });
        AlertDialog alert=builder.create();
        alert.show();
        
      }
    });
  }
  return profile;
  }
}
