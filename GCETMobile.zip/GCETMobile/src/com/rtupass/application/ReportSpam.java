package com.rtupass.application;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

import com.android.volley.Request.Method;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.rtupass.application.app.AppConfig;
import com.rtupass.application.app.AppController;
import com.rtupass.application.helper.SessionManager;

import android.app.ActionBar;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class ReportSpam extends Activity {
ActionBar ab;
EditText s_rollno,s_reason;
TextView instructn;
RelativeLayout spam_window;
Button proceed,report;
String error_validations;
String user_rollno,user_uid,spam_rollno,spam_reason,UserName;
private ProgressDialog pDialog;
StringOperations obj;
SessionManager session;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_report_spam);
		
		session=new SessionManager(getApplicationContext());
		obj=new StringOperations();
		pDialog=new ProgressDialog(this);
		pDialog.setCancelable(false);
		
		//retrieving user details--------
		user_rollno=session.returnRollno();
		user_uid=session.returnUid();
		UserName=session.returnName();
		
		ab=getActionBar();
		ab.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#000000")));
        ab.setIcon(new ColorDrawable(getResources().getColor(android.R.color.transparent)));
        ab.setTitle("  Report Spam");
        
        s_rollno=(EditText)findViewById(R.id.rollno);
        s_reason=(EditText)findViewById(R.id.reason);
        instructn=(TextView)findViewById(R.id.textView1);
        proceed=(Button)findViewById(R.id.button1);
        report=(Button)findViewById(R.id.btn_report);
        spam_window=(RelativeLayout)findViewById(R.id.relative1);
        
        spam_window.setVisibility(View.GONE);
        
        proceed.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				instructn.setVisibility(View.GONE);
				proceed.setVisibility(View.GONE);
				spam_window.setVisibility(View.VISIBLE);
			}
		});
        
        report.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				 spam_reason = s_reason.getText().toString().trim();
			 	 spam_rollno=s_rollno.getText().toString().trim();
				
				if (!user_rollno.isEmpty() && !user_uid.isEmpty() && !spam_rollno.isEmpty() && !spam_reason.isEmpty() ) {
					if(validation(spam_rollno,spam_reason)){
						reportSpam(user_rollno,user_uid,spam_rollno,spam_reason); 
					}
					else{
						Toast.makeText(getApplicationContext(), error_validations, Toast.LENGTH_LONG).show();
					}
				} else {
					Toast.makeText(getApplicationContext(),"Please fill all entries.", Toast.LENGTH_LONG).show();
				}
			}
			
		});
        
        
        
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		//super.onBackPressed();
		//Toast.makeText(getApplicationContext(), "You pressed back.", Toast.LENGTH_SHORT).show();
		startActivity(new Intent(ReportSpam.this,HelpActivity.class));
		finish();	
	
	}
	
	private boolean validation(String spam_rollno_,String spam_reason_){
		boolean no_error=true;
		
		if(spam_reason_.length()<20){
			error_validations="Please enter a brief reason!";
			no_error=false;
		}
		if(!obj.isValidRollno(spam_rollno_)){
			error_validations="It is not a correct roll number";	
			no_error=false;
		}
		if(spam_rollno_.equalsIgnoreCase(user_rollno)){
			error_validations="Are you kidding me? You can't just report yourself spam.";
			no_error=false;
		}
	
		return no_error;
	}
//---------------------------------------------------------------------------------------------------------------------------------------
//------volley request----reportSpam(user_rollno,user_uid,spam_rollno,spam_reason);
	private void reportSpam(final String user_rollno_, final String user_uid_,final String spam_rollno_,final String spam_reason_) {
		// Tag used to cancel the request
		String tag_string_req = "report_spam";

		pDialog.setMessage("It will take a moment....");
		showDialog();

		StringRequest strReq = new StringRequest(Method.POST,AppConfig.URL_Report_Spam, new Response.Listener<String>() {

			@Override
			public void onResponse(String response) {
				//Log.d(TAG, "Register Response: " + response.toString());
				hideDialog();

				try {
					JSONObject json = new JSONObject(response);
	                  boolean error = json.getBoolean("error");
					        if (!error) {

					                  String message = json.getString("message");

					                  Toast.makeText(getApplicationContext(), message+" Thankyou "+UserName, Toast.LENGTH_LONG).show();
					                    // Launch main activity
					                  startActivity(new Intent(ReportSpam.this,HelpActivity.class));
					                  finish();
					                  
					        } else {

					          // Error occurred in posting. Get the error
					          // message
					          String errorMsg = json.getString("error_msg");
					          Toast.makeText(getApplicationContext(),errorMsg, Toast.LENGTH_LONG).show();
					        }
				} catch (JSONException e) {
					e.printStackTrace();
					Toast.makeText(getApplicationContext(),"Unknown Error occured!", Toast.LENGTH_LONG).show();
				}

			}
		}, new Response.ErrorListener() {

			@Override
			public void onErrorResponse(VolleyError error) {
				//Log.e(TAG, "Registration Error: " + error.getMessage());
				Toast.makeText(getApplicationContext(),"Network Error!!", Toast.LENGTH_LONG).show();
				hideDialog();
			}
		}) {

			@Override
			protected Map<String, String> getParams() {
				// Posting params to register url
				Map<String, String> params = new HashMap<String, String>();
				params.put("uid", user_uid_);
				params.put("posted_by", user_rollno_);
				params.put("reason",spam_reason_);
				params.put("spam",spam_rollno_);

				return params;
			}

		};

		// Adding request to request queue
		AppController.getInstance().addToRequestQueue(strReq, tag_string_req);
	}
	private void showDialog() {
		if (!pDialog.isShowing())
			pDialog.show();
	}

	private void hideDialog() {
		if (pDialog.isShowing())
			pDialog.dismiss();
	}
}
