package com.rtupass.application;

import java.util.ArrayList;

import com.rtupass.application.DivisionEngg.ViewDialogEngg;

import android.app.ActionBar;
import android.app.Activity;
import android.app.Dialog;
import android.app.ActionBar.LayoutParams;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class DivisionMba extends Activity {
	ExpandableHeightGridView grid_mba;
	private String DB_NAME="college.db";
	ViewDialogMBA alert;
	SQLiteDatabase database;
	ArrayList<String> mba_name,mba_description;
	ActionBar actionBar;
	Button info_btn;
	String name_mba[]={"Faculty","Infrastructure","About","Objective","Admission","Eligibility"};
	int images_mba[]={R.drawable.mba_faculty,R.drawable.mba_infra,R.drawable.mba_about,R.drawable.mba_objective,R.drawable.mba_admission,R.drawable.mba_eligibility};
		@Override
		protected void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.activity_division_mba);
			alert= new ViewDialogMBA();
			//action bar
			 	actionBar = getActionBar();
		        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#000000")));
		        actionBar.setIcon(new ColorDrawable(getResources().getColor(android.R.color.transparent)));
		        actionBar.setTitle(" M.B.A");
			info_btn=(Button)findViewById(R.id.button1);
			grid_mba=(ExpandableHeightGridView)findViewById(R.id.gridView_mba);
			
			database=openOrCreateDatabase(DB_NAME, Context.MODE_PRIVATE,null);
	        try {
				mba_name=new ArrayList<String>();
				mba_description=new ArrayList<String>();
			String query= "select department_name,dept_description from department where department_id='mba' ";
				Cursor c=database.rawQuery(query, null);
				c.moveToFirst();
				if(!c.isAfterLast()) {
					do {
						String name = c.getString(0);
						String description=c.getString(1);
						mba_name.add(name);
						mba_description.add(description);
					} while (c.moveToNext());
				}
				c.close();
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	       database.close();
			
			grid_mba.setAdapter(new myGridAdapterEngg(DivisionMba.this, images_mba, name_mba));
			grid_mba.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
					// TODO Auto-generated method stub
					//Toast.makeText(getApplicationContext(), name_mba[position], Toast.LENGTH_SHORT).show();
					alert.showDialogue(DivisionMba.this,mba_name.get(position),	mba_description.get(position));
					
				}
			});
			
			info_btn.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					showCustomDialog();
				}
			});
			
		}
		@Override
			public void onBackPressed() {
				// TODO Auto-generated method stub
				//super.onBackPressed();
				//Toast.makeText(getApplicationContext(), "You pressed back.", Toast.LENGTH_SHORT).show();
				startActivity(new Intent(DivisionMba.this,DivisionsActivity.class));
				finish();	
			
			}
		private void showCustomDialog(){
			Context context = getApplicationContext();
	        // Create layout inflator object to inflate toast.xml file
	        LayoutInflater inflater = getLayoutInflater();
	          
	        // Call toast.xml file for toast layout 
	        View toastRoot = inflater.inflate(R.layout.custom_toast, null);
	          
	        Toast toast = new Toast(context);
	         
	        // Set layout to toast 
	        toast.setView(toastRoot);
	        toast.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL, 0, 0);
	        toast.setDuration(Toast.LENGTH_LONG);
	        toast.show();
		}
		public class ViewDialogMBA{
			public void showDialogue(Context activity,final String string,final String string3) {
				// TODO Auto-generated method stub
				 final Dialog dialog = new Dialog(activity);
			        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
			        dialog.setCancelable(true);
			        dialog.setContentView(R.layout.lab_description_dialogue);
			        
			        
				TextView heading_name=(TextView)dialog.findViewById(R.id.lab_name);
				LinearLayout linear=(LinearLayout) dialog.findViewById(R.id.linearmarks);
				Button ok=(Button)dialog.findViewById(R.id.button1);
				final TextView content=(TextView)dialog.findViewById(R.id.textView4);
				
				linear.setVisibility(View.GONE);
				heading_name.setText(string);
				content.setText(string3);
				ok.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						dialog.dismiss();
					}
				});
				
				dialog.show();
				Window window = dialog.getWindow();
				window.setLayout(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
			
				
			}
		}
		

		
}
