package com.rtupass.application;

import com.rtupass.application.helper.SessionManager;

import android.animation.ObjectAnimator;
import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class HelpActivity extends Activity {
	TextView emergency,faq,report,enquire;
	ActionBar ab;
	ImageView logo;
	SQLiteDatabase database;
	SessionManager session;
	private static final String DB_NAME = "college.db";
	private void flipIt(final View viewToFlip) {
		ObjectAnimator flip = ObjectAnimator.ofFloat(viewToFlip, "rotationY", 0f, 360f);
		flip.setDuration(3000);
		flip.setInterpolator(new OvershootInterpolator());
		flip.start();

	}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_help);
		
		ab=getActionBar();
		ab.hide();
		session=new SessionManager(getApplicationContext());
		
		
		ExternalDbOpenHelper dbOpenHelper = new ExternalDbOpenHelper(this, DB_NAME);
        database = dbOpenHelper.openDataBase();
        dbOpenHelper.close();
        
		logo=(ImageView)findViewById(R.id.imageViewlogo);
		emergency=(TextView)findViewById(R.id.emergency);
		faq=(TextView)findViewById(R.id.faq);
		report=(TextView)findViewById(R.id.report);
		enquire=(TextView)findViewById(R.id.enquire);
		
		logo.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				flipIt(logo);
			}
		});
		
		emergency.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(HelpActivity.this,Emergency.class));
				finish();
			}
				});
		faq.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(HelpActivity.this,FAQActivity.class));
				finish();
			}
				});
		report.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						//
						if(session.isLoggedIn()){
							startActivity(new Intent(HelpActivity.this,ReportSpam.class));
							finish();
						}else {
							Toast.makeText(getApplicationContext(), "Please Login First!!", Toast.LENGTH_SHORT).show();
						}
					}
				});
		enquire.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				//
				if(session.isLoggedIn()){
					startActivity(new Intent(HelpActivity.this,Enquiry.class));
					finish();
				}else {
					Toast.makeText(getApplicationContext(), "Please Login First!!", Toast.LENGTH_SHORT).show();
				}
			}
		});

	}


}
