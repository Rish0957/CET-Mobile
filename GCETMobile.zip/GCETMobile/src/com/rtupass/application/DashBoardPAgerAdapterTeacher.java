package com.rtupass.application;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

public class DashBoardPAgerAdapterTeacher extends FragmentStatePagerAdapter {
    public DashBoardPAgerAdapterTeacher(FragmentManager fm) {
		// TODO Auto-generated constructor stub
		super(fm);
	}

	@Override
	public Fragment getItem(int i) {
		switch (i) {
        case 0:
            //Fragment for profile
        	return new TeacherProfile();
        case 1:
           //Fragment for sharing information
            return new GenerateNotification();
            
        }
		return null;
		
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return 2; //No of Tabs
	}


    }