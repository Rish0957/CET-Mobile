package com.rtupass.application;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.TextView;

public class DivisionsActivity extends Activity {
	android.app.ActionBar ab;
	private static final String DB_NAME = "college.db";
	TextView engg,mba,app_science,administration;
	ImageView logo;
	private void flipIt(final View viewToFlip) {
		ObjectAnimator flip = ObjectAnimator.ofFloat(viewToFlip, "rotationY", 0f, 360f);
		flip.setDuration(3000);
		flip.setInterpolator(new OvershootInterpolator());
		flip.start();

	}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_divisions);
		ab=getActionBar();
		ab.hide();
		
		ExternalDbOpenHelper dbOpenHelper = new ExternalDbOpenHelper(this, DB_NAME);
        dbOpenHelper.openDataBase();
        dbOpenHelper.close();
		logo=(ImageView)findViewById(R.id.imageView1);
		engg=(TextView)findViewById(R.id.engineering);
		mba=(TextView)findViewById(R.id.mba);
		app_science=(TextView)findViewById(R.id.app_science);
		administration=(TextView)findViewById(R.id.administration);
		
		logo.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				flipIt(logo);
			}
		});
		
		engg.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				//Toast.makeText(getApplicationContext(), "You clicked Enginnering Section!!", Toast.LENGTH_SHORT).show();
				startActivity(new Intent(DivisionsActivity.this,DivisionEngg.class));
				finish();
			}
				});
		mba.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						//Toast.makeText(getApplicationContext(), "You clicked MBA Section!!", Toast.LENGTH_SHORT).show();
						startActivity(new Intent(DivisionsActivity.this,DivisionMba.class));
						finish();
					}
				});
		app_science.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				//Toast.makeText(getApplicationContext(), "You clicked Applied Science Section!!", Toast.LENGTH_SHORT).show();
				startActivity(new Intent(DivisionsActivity.this,DivisionAppSci.class));
				finish();
			}
		});
		administration.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				//Toast.makeText(getApplicationContext(), "You clicked Administration Section!!", Toast.LENGTH_SHORT).show();
			}
		});
		
	}
	
	

}
