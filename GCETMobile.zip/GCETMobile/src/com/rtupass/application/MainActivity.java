package com.rtupass.application;

import com.rtupass.application.app.AppConfig;
import com.rtupass.application.helper.SessionManager;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.animation.AnticipateOvershootInterpolator;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends Activity {
ExpandableHeightGridView grid;
boolean doubleBackToExitPressedOnce = false;
Button login_signUp,teacher_sing_in,about_app,help;
SessionManager session;
LinearLayout teacher_login;
int touchCounter=0;
ImageView logo;
String name[]={"Notifications","Map","About","Teacher Directory","Divisions","Links","Placement Corner","Study Material","DashBoard"};
int image[]={R.drawable.ic_notification,R.drawable.ic_map,R.drawable.ic_about_college,R.drawable.ic_teachers_directory,R.drawable.ic_courses,
		R.drawable.ic_links,R.drawable.ic_placement,R.drawable.ic_study_material,R.drawable.ic_dashboard};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		//checking for isLoggedIn()
		session = new SessionManager(getApplicationContext());
		
		login_signUp=(Button)findViewById(R.id.login_signUp);
		logo=(ImageView)findViewById(R.id.logo);
		 teacher_login=(LinearLayout)findViewById(R.id.layoutToHideTeacher);
		 help=(Button)findViewById(R.id.help);
		
		 help.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(MainActivity.this,HelpActivity.class));
			}
		});
		//making them invisible intially
		teacher_login.setVisibility(View.GONE); 
		
		
		
			logo.setOnTouchListener(new OnTouchListener() {
				
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					// TODO Auto-generated method stub
					if(!session.isLoggedIn()){
					
							if(teacher_login.getVisibility()==View.GONE){
								touchCounter++;
								Log.d("Counter", ""+touchCounter);
								if(touchCounter==6){
									Toast.makeText(getApplicationContext(), "Touch 4 more times", Toast.LENGTH_SHORT).show();
								}
								if(touchCounter==10){
									teacher_login.setVisibility(View.VISIBLE);
									flipIt(logo);
									Toast.makeText(getApplicationContext(), "Teacher's Login Section Unlocked!!", Toast.LENGTH_LONG).show();
								}
								 new Handler().postDelayed(new Runnable() {
		
								        @Override
								        public void run() {
								            touchCounter=0;                       
								        }
								    }, 5000);
							}
							else{
								flipIt(logo);
							}
					}
					else{
						flipIt(logo);
					}
					return false;
				}
			});
		
		
		teacher_sing_in=(Button)findViewById(R.id.teacherLogin);
		about_app=(Button)findViewById(R.id.about_btn);
		
		if(session.isLoggedIn()){
			LinearLayout hideit=(LinearLayout)findViewById(R.id.hideit);
			hideit.setVisibility(View.GONE);
			
		}
		
		about_app.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				ViewDialog alert = new ViewDialog();
				alert.showDialog(MainActivity.this);
			}
		});
		
		grid=(ExpandableHeightGridView)findViewById(R.id.gridView);
		grid.setAdapter(new myGridAdapter(MainActivity.this, image, name));
		grid.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				// TODO Auto-generated method stub
				switch (position) {
				case 0:
					if(session.isLoggedIn()){
					startActivity(new Intent(MainActivity.this,NotificationActivity.class));
					}else{
						Toast.makeText(getApplicationContext(), "Please Login First!!",Toast.LENGTH_SHORT).show();
					}
										break;
				case 1:
					startActivity(new Intent(MainActivity.this,GCETMap.class));
					break;
				case 2:
					startActivity(new Intent(MainActivity.this,AboutCollege.class));
					break;
				case 3:
					startActivity(new Intent(MainActivity.this,TeachersDirectory.class));
					break;
				case 4:
					startActivity(new Intent(MainActivity.this,DivisionsActivity.class));
					break;
				case 5:
					startActivity(new Intent(MainActivity.this,LinksActivity.class));
					break;
				case 6:
					startActivity(new Intent(MainActivity.this,PlacementCorner.class));
					break;
				case 7:
					startActivity(new Intent(MainActivity.this,SplashActiviyRTUPass.class));
					break;
				case 8:
					if(session.isLoggedIn()){
					startActivity(new Intent(MainActivity.this,DashBoardActivity.class));
					}else{
						Toast.makeText(getApplicationContext(), "Please Login First!!",Toast.LENGTH_SHORT).show();
					}
					break;	
				}
			}	
		});
		login_signUp.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent i=new Intent(MainActivity.this,LoginActivity.class);
				startActivity(i);
				
			}
		});
		teacher_sing_in.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent i=new Intent(MainActivity.this,TeacherLoginActivity.class);
				startActivity(i);
				
			}
		});
	}
	private void flipIt(final View viewToFlip) {
		ObjectAnimator flip = ObjectAnimator.ofFloat(viewToFlip, "rotationY", 0f, 360f);
		flip.setDuration(3000);
		flip.setInterpolator(new AnticipateOvershootInterpolator());
		flip.start();

	}
	@Override
	public void onBackPressed() {
	    if (doubleBackToExitPressedOnce) {
	    	Intent startMain = new Intent(Intent.ACTION_MAIN); 
	    	startMain.addCategory(Intent.CATEGORY_HOME); 
	    	startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK); 
	    	startActivity(startMain); 
	    	finish();
	    }

	    this.doubleBackToExitPressedOnce = true;
	    Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

	    new Handler().postDelayed(new Runnable() {

	        @Override
	        public void run() {
	            doubleBackToExitPressedOnce=false;                       
	        }
	    }, 2000);
	} 
	public class ViewDialog {

	    public void showDialog(Context activity){
	    	Context context=activity;
	        final Dialog dialog = new Dialog(context);
	        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
	        dialog.setCancelable(true);
	        dialog.setContentView(R.layout.about_app_dialog);
	        
	        LinearLayout website=(LinearLayout)dialog.findViewById(R.id.visit_website);
	        LinearLayout share=(LinearLayout) dialog.findViewById(R.id.share_on_whatsapp);
	        LinearLayout hike=(LinearLayout)dialog.findViewById(R.id.share_on_hike);
	        
	        share.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent whatsappIntent = new Intent(Intent.ACTION_SEND);
					whatsappIntent.setType("text/plain");
					whatsappIntent.setPackage("com.whatsapp");
					String message="Download the all new GCET mobile app of our college.It's fun and has many helpful features for students like study material,placements corner and many more. Go to http://play.google.com/gcetmobileapp";
					whatsappIntent.putExtra(Intent.EXTRA_TEXT,message );
					try {
					    startActivity(whatsappIntent);
					} catch (android.content.ActivityNotFoundException ex) {
					   Toast.makeText(getApplicationContext(),"Whatsapp is not installed in your phone!!", Toast.LENGTH_SHORT).show();
					}
				}
			});
	        
	        website.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(AppConfig.WebsiteUrl));
					startActivity(browserIntent);
				}
			});
	        
	        hike.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent hikeIntent = new Intent(Intent.ACTION_SEND);
					hikeIntent.setType("text/plain");
					hikeIntent.setPackage("com.bsb.hike");
					String message="Download the all new GCET mobile app of our college.It's fun and has many helpful features for students like study material,placements corner and many more. Go to http://play.google.com/gcetmobileapp";
					hikeIntent.putExtra(Intent.EXTRA_TEXT,message );
					try {
					    startActivity(hikeIntent);
					} catch (android.content.ActivityNotFoundException ex) {
					   Toast.makeText(getApplicationContext(),"Hike is not installed in your phone!!", Toast.LENGTH_SHORT).show();
					}
				}
			});
	        
	        dialog.show();

	    }
	}

}
