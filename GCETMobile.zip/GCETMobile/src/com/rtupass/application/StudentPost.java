package com.rtupass.application;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.android.volley.AuthFailureError;
import com.android.volley.Cache;
import com.android.volley.Request.Method;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.StringRequest;
import com.rtupass.application.app.AppConfig;
import com.rtupass.application.app.AppController;
import com.rtupass.application.helper.SessionManager;

import LruBitmapCache.FeedItem;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.AnticipateOvershootInterpolator;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class StudentPost  extends Fragment {
    private static final String TAG = StudentPost.class.getSimpleName();
    private ListView listView;
    private FeedListAdapter listAdapter;
    private List<FeedItem> feedItems;
    public String trimmed_roll_no;
    private ProgressDialog pDialog;
    Button load_feeds;
    TextView refresh_btn;
    SessionManager session;
    //SwipeRefreshLayout mySwipe;
    AlertDialogManager alert;
    String uid;
    private String URL_STUDENT_FEED = AppConfig.URL_STUDENT_FEEDS;
 
    @SuppressLint("NewApi")
    @Override
     public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
         View feeds = inflater.inflate(R.layout.frag_student_post, container, false);
         setHasOptionsMenu(false);
        session=new SessionManager(getActivity());
	        if(!session.returnRollno().isEmpty()){
	        	trimmed_roll_no=session.returnRollno().substring(0,7);
	        	Log.d("trimmed_roll_no", trimmed_roll_no);
	        }
	        uid=session.returnUid();
	        
			 listView = (ListView) feeds.findViewById(R.id.list);   
			 load_feeds=(Button)feeds.findViewById(R.id.button_load_feeds);
			 refresh_btn=(TextView)feeds.findViewById(R.id.refresh_feed);
			 
			 refresh_btn.setVisibility(View.GONE);
			 listView.setVisibility(View.GONE);
			 
			 load_feeds.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					load_feeds.setVisibility(View.GONE);
					 try {
						 
						 listView.setVisibility(View.VISIBLE);
						 refresh_btn.setVisibility(View.VISIBLE);
						 
						// We first check for cached request
						Cache cache = AppController.getInstance().getRequestQueue().getCache();
						Cache.Entry entry = cache.get(URL_STUDENT_FEED);
						if (entry != null) {
						    // fetch the data from cache
						    try {
						        String data = new String(entry.data, "UTF-8");
						        Log.d("skjdnksjdcsdjcds", data);
						        
						            try {
										parseJsonFeed(data);
									} catch (Exception e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
						        
						    } catch (UnsupportedEncodingException e) {
						        e.printStackTrace();
						    }
 
						} else {
						     //making fresh volley request and getting json
						   freshVolleyRequest2();
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace(); 
						refresh_btn.setVisibility(View.GONE);
			            listView.setVisibility(View.GONE);
						load_feeds.setVisibility(View.VISIBLE);
					}
				}
			});
			 
			 refresh_btn.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					if(refresh_btn.getVisibility()==View.VISIBLE){
						flipIt(refresh_btn);
						refreshList2();
					}
				}
			});
			 
		        //process dialogue
		        pDialog = new ProgressDialog(getActivity());
		        pDialog.setCancelable(false);
		        
		        feedItems = new ArrayList<FeedItem>();
		 
		        listAdapter = new FeedListAdapter(getActivity(), feedItems);
		        listView.setAdapter(listAdapter);

		        return feeds;  
      }
    private void flipIt(final View viewToFlip) {
		ObjectAnimator flip = ObjectAnimator.ofFloat(viewToFlip, "rotationX", 360f, 0f);
		flip.setDuration(1000);
		flip.setInterpolator(new AnticipateOvershootInterpolator());
		flip.start();

	}
    public void freshVolleyRequest2(){
    	
        pDialog.setMessage("Fetching Data....");
        showDialog();
    	 StringRequest jsonReq = new StringRequest( Method.POST,URL_STUDENT_FEED, new Response.Listener<String>(){
     		//new JsonObjectRequest(Method.GET,URL_STUDENT_FEED, null, new Response.Listener<JSONObject>() {

                 @Override
                 public void onResponse(String response) {
                     VolleyLog.d(TAG, "Response: " + response.toString());
                     if (response != null) {
                         parseJsonFeed(response);
                         hideDialog();
                     }
                 }
             }, new Response.ErrorListener() {

                 @Override
                 public void onErrorResponse(VolleyError error) {
                     //VolleyLog.d(TAG, "Error: " + error.getMessage());
                     Toast.makeText(getActivity(),"Something went wrong!! Check internet.", Toast.LENGTH_LONG).show();
                     hideDialog();
                     load_feeds.setVisibility(View.VISIBLE);
                 }
             }){
     	@Override
     	protected Map<String, String> getParams() throws AuthFailureError {
     		 Map<String, String> params = new HashMap<String, String>();
              params.put("trimmed_roll_no", trimmed_roll_no);
              params.put("uid", uid);
              return params;
     	}
     	
     };

     // Adding request to volley request queue
     AppController.getInstance().addToRequestQueue(jsonReq);
    }
    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }
    /**
     * Parsing json reponse and passing the data to feed view list adapter
     * */
    private void parseJsonFeed(String responseString) {
        try {
        	JSONObject response=new JSONObject(responseString);
        	Log.d("Json",response.toString());
        	boolean  error = response.getBoolean("error");
			
           if(!error){
        	   JSONArray feedArray = response.getJSONArray("feed");
        	   
               for (int i = 0; i < feedArray.length(); i++) {
                   JSONObject feedObj = (JSONObject) feedArray.get(i);
    
                   FeedItem item = new FeedItem();
                   item.setId(feedObj.getInt("post_id"));
                   item.setName(feedObj.getString("posted_by"));
                   item.setStatus(feedObj.getString("content"));
                   item.setProfilePic(feedObj.isNull("profile_pic_url") ? null : feedObj.getString("image"));
                   item.setTimeStamp(feedObj.getString("posted_on"));
                   item.setRoll_no(feedObj.getString("roll_no"));
                   item.setBranch(feedObj.getString("branch"));
                   
                   feedItems.add(item);
               }
           }
           else {
               // Error in login. Get the error message
               String errorMsg = response.getString("error_msg");
               Toast.makeText(getActivity(),errorMsg, Toast.LENGTH_LONG).show();
           }
            // notify data changes to list adapater
            listAdapter.notifyDataSetChanged();
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(getActivity(),"Uncaught Error!! Check Internet.", Toast.LENGTH_LONG).show();
        }
    }
    public void refreshList2(){
    	//Log.d("Inside refreshlist block", "true");
 		   if(!feedItems.isEmpty()){
 			   feedItems.clear();
 			   }
 		freshVolleyRequest2();
 	   
    }
 
    
}